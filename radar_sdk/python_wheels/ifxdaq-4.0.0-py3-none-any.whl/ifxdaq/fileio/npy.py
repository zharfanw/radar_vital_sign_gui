"""This module contains the implementation of a recorder and reader for numpy files (``.npy``).

See Also:
    * :ref:`radar`
    * :ref:`depth`
    * :class:`~ifxdaq.record.DataRecorder`: Generic data recorder.

Examples:
    Import

    >>> from ifxdaq.fileio.npy import ReaderNpy, RecorderNpy

    Generate stack of 10 frames (could also arrive from a live sensor):

    >>> import numpy as np
    >>> from ifxdaq.sensor.abc import Frame, FrameFormat
    >>> frames = [Frame(t, np.random.randn(3,64,128).astype("uint16")) for t in range(10)]
    >>> frame_format = FrameFormat(dtype=np.dtype("uint16"), fps=10.0, shape=(3,64,128))

    Write the data frame by frame to the file:

    >>> with RecorderNpy("demo.npy", frame_format) as rec:
    ...     for frame in frames:
    ...         rec.write(frame)

    Read the data frame by frame from the file:

    >>> with ReaderNpy("demo.npy") as read:
    ...     for frame in read:
    ...         print(frame)
"""

from __future__ import annotations

import logging
import struct
from typing import TYPE_CHECKING, Generator, Optional, Tuple

import numpy as np
import numpy.lib.format  # pylint: disable=unused-import

from ifxdaq.errors import RecorderError
from ifxdaq.fileio.abc import ReaderABC, RecorderABC

if TYPE_CHECKING:
    from ifxdaq.custom_typing import _PathLike
    from ifxdaq.sensor.abc import FrameFormat

log = logging.getLogger(__name__)

__all__ = ["RecorderNpy", "ReaderNpy"]


class RecorderNpy(RecorderABC):
    """Write data into numpy files (``.npy``).

    This class is used to record data and store it in ``.npy`` files.

    Args:
        file: File to write.
        frame_format: Format of the frames.

    See Also:
        * :class:`~ifxdaq.fileio.npy.ReaderNpy`: Reader for ``.npy`` files.
    """

    file_suffix = ".npy"

    major_version = 1
    minor_version = 0
    header_length = 2038

    def __init__(self, file: _PathLike, frame_format: FrameFormat) -> None:
        self._fortran_order: Optional[bool] = None
        super().__init__(file, frame_format)

    def _open(self) -> None:
        self._file_data = open(self._file_name, "wb")  # pylint: disable=consider-using-with
        self._file_data.seek(RecorderNpy.header_length + 10)

    def _write_header(self) -> None:
        """Write the header of a .npy file to the start of the file."""
        magic = np.lib.format.magic(RecorderNpy.major_version, RecorderNpy.minor_version)
        length = struct.pack("<H", RecorderNpy.header_length)
        array_format = (
            f"{{'descr': '{np.lib.format.dtype_to_descr(self._dtype)}', "
            f"'fortran_order': {self._fortran_order}, "
            f"'shape': ({', '.join([str(x) for x in self._shape])}), }}"
        ).ljust(RecorderNpy.header_length - 1) + "\n"

        header = bytes(magic) + length + bytes(array_format, encoding="ascii")

        self._file_data.seek(0)
        self._file_data.write(header)

    def _write(self, data: np.ndarray) -> None:
        """Write an array into the file.

        Args:
            data: Numpy data.

        Raises:
            RecorderError: If invalid `data` (shape/dtype/memory-layout) was passed.
        """
        if self._fortran_order is None:
            self._fortran_order = data.flags.f_contiguous and not data.flags.c_contiguous

        if self._dtype != data.dtype:
            raise RecorderError("Type must not change.")
        if self._fortran_order != (data.flags.f_contiguous and not data.flags.c_contiguous):
            raise RecorderError("Memory layout must not change.")
        if self._shape != data.shape:
            raise RecorderError("Shape must not change.")

        data = np.asanyarray(data)
        data_binary = data.tobytes("C" if not self._fortran_order else "F")
        self._file_data.write(data_binary)

    def _close(self) -> None:
        self._shape = (self._frame_number,) + self._shape
        self._write_header()
        self._file_data.close()


class ReaderNpy(ReaderABC):
    """Read data from numpy files (``.npy``).

    This class is used to read data from ``.npy`` files.

    Args:
        file: File to read.

    See Also:
        * :class:`~ifxdaq.fileio.npy.RecorderNpy`: Recorder for ``.npy`` files.
    """

    def __init__(self, file: _PathLike):
        self._file: np.memmap
        super().__init__(file)

    @property
    def dtype(self) -> np.dtype:
        """Data type of the data frames."""
        return self._file.dtype

    @property
    def shape(self) -> Tuple[int, ...]:
        """Shape of the data frames."""
        return self._file.shape[1:]

    def _close(self) -> None:
        pass

    def _open(self) -> None:
        self._file = np.load(str(self._file_name), mmap_mode="r")

    def _init_data_generator(self) -> Generator[np.ndarray, None, None]:
        for frame in self._file:
            yield frame
