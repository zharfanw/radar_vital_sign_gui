"""This package contains implementations to write data to and read data from files."""

FILE_FORMAT_VERSION = "1.0.0"
TIMESTAMP_SUFFIX = "_timestamp.csv"
META_DATA_FILE = "meta.json"
FILE_FORMAT_VERSION_FILE = "format.version"
CONFIG_FILE = "config"
