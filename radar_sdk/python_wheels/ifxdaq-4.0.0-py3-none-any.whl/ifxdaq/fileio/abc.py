"""This module contains the abstract classes for recorders and readers."""

from __future__ import annotations

import json
import logging
import time
from abc import ABC, abstractmethod
from pathlib import Path
from typing import TYPE_CHECKING, Any, Dict, Generator, List, Optional, Tuple, Type

from ifxdaq.fileio import CONFIG_FILE, META_DATA_FILE, TIMESTAMP_SUFFIX
from ifxdaq.sensor.abc import Frame, FrameFormat
from ifxdaq.utils.common import verify_file

if TYPE_CHECKING:
    from types import TracebackType

    import numpy as np

    from ifxdaq.custom_typing import _PathLike

try:
    from functools import cached_property
except ImportError:
    from backports.cached_property import cached_property  # type: ignore

log = logging.getLogger(__name__)

__all__: List[str] = []


# pylint: disable=too-many-instance-attributes
class RecorderABC(ABC):
    """Abstract recorder class.

    This class should be used as a boilerplate for different recorders. Please
    follow the API of the abstract methods to create compliant recorder classes.

    Args:
        file: File to write.
        frame_format: Format of the frames.
    """

    file_suffix: str
    LOG_INTERVAL_S = 5

    def __init__(self, file: _PathLike, frame_format: FrameFormat) -> None:
        super().__init__()
        self._dtype = frame_format.dtype
        self._shape = frame_format.shape
        self._fps = frame_format.fps
        self._file_name = Path(file)
        self._file_timestamp_name = self._file_name.parent / f"{self._file_name.stem}{TIMESTAMP_SUFFIX}"
        self._file_timestamp = open(  # pylint: disable=consider-using-with
            self._file_timestamp_name, "w", encoding="utf-8"
        )
        log.debug("%s: %s | Opened timestamps file.", type(self).__name__, self._file_timestamp_name.as_posix())
        self._open()
        log.debug("%s: %s | Opened data file.", type(self).__name__, self._file_name.as_posix())

        self._frame_number = 0
        self._timestamp_last_log = time.time()
        self._frame_count_last_log = 0

    def write(self, frame: Frame) -> None:
        """Write data with the recorder.

        Args:
            frame: The data frame.
        """
        self._file_timestamp.write(f"{frame.timestamp}\n")
        self._write(frame.data)

        self._frame_number += 1

        timestamp = time.time()
        if (timestamp - self._timestamp_last_log) > RecorderABC.LOG_INTERVAL_S:
            frame_rate = (self._frame_number - self._frame_count_last_log) / (timestamp - self._timestamp_last_log)
            log.debug(
                "%s: %s | Wrote frame number %d. (%.2f fps)",
                type(self).__name__,
                self._file_name.as_posix(),
                self._frame_number,
                frame_rate,
            )
            self._timestamp_last_log = timestamp
            self._frame_count_last_log = self._frame_number

    def close(self) -> None:
        """Close the recorder and all corresponding files."""
        self._file_timestamp.close()
        log.debug("%s: %s | Closed timestamps file.", type(self).__name__, self._file_timestamp_name.as_posix())
        self._close()
        log.debug("%s: %s | Closed data file.", type(self).__name__, self._file_name.as_posix())

    def __enter__(self: "RecorderABC") -> "RecorderABC":
        log.debug("%s: %s | Entered context manager.", type(self).__name__, self._file_name.as_posix())
        return self

    def __exit__(
        self,
        exc_type: Optional[Type[BaseException]],
        exc_value: Optional[BaseException],
        traceback: Optional[TracebackType],
    ) -> None:
        self.close()
        log.debug("%s: %s | Exited context manager.", type(self).__name__, self._file_name.as_posix())

    @abstractmethod
    def _open(self) -> None:
        raise NotImplementedError

    @abstractmethod
    def _write(self, data: Any) -> None:
        raise NotImplementedError

    @abstractmethod
    def _close(self) -> None:
        raise NotImplementedError


class ReaderABC(ABC):
    """Abstract reader class.

    This class should be used as a boilerplate for different readers. Please
    follow the API of the abstract methods to create compliant reader classes.

    Args:
        file: File to read.
    """

    def __init__(self, file: _PathLike):
        self._fps: float
        self._len: int
        self._timestamps: List[float]

        self._file_name = Path(file)
        verify_file(self._file_name)
        self._rec_dir = self._file_name.parent
        self._file_timestamp_name = self._file_name.parent / f"{self._file_name.stem}{TIMESTAMP_SUFFIX}"
        self._file_timestamp = open(  # pylint: disable=consider-using-with
            self._file_timestamp_name, "r", encoding="utf-8"
        )
        log.debug("%s: %s | Opened timestamps file.", type(self).__name__, self._file_timestamp_name.as_posix())
        self._open()
        self._generator = self._init_data_generator()
        log.debug("%s: %s | Opened data file.", type(self).__name__, self._file_name.as_posix())

    @cached_property
    def config_file(self) -> Optional[Path]:
        """Configuration file of the sensor used for the recording."""
        config_file = None
        config_files = list(self._rec_dir.glob(f"{CONFIG_FILE}.*"))
        if len(config_files) == 0:
            log.warning("%s: %s | No configuration file available.", type(self).__name__, self._rec_dir)
        elif len(config_files) > 1:
            log.warning("%s: %s | Multiple configuration files available.", type(self).__name__, self._rec_dir)
        else:
            config_file = config_files[0]
        return config_file

    @cached_property
    def meta_data(self) -> Optional[Dict[str, str]]:
        """The device's meta data (e.g. driver version) used for the recording."""
        meta_data = None
        try:
            with open(self._rec_dir / META_DATA_FILE, "r", encoding="utf-8") as file:
                return json.load(file)
        except FileNotFoundError:
            log.warning("%s: %s No meta data available.", type(self).__name__, self._rec_dir)
        return meta_data

    @property
    def file_name(self) -> Path:
        """Name of the file."""
        return self._file_name

    @property
    @abstractmethod
    def dtype(self) -> np.dtype:
        """Data type of the data frames (e.g. float32 or uint8)."""
        raise NotImplementedError

    @cached_property
    def fps(self) -> float:
        """Frame rate of the recording."""
        if not hasattr(self, "_fps"):
            # This could be implemented more efficient by reading just the first & last line of a file instead of all.
            self._fps = (len(self.timestamps) - 1) / (self.timestamps[-1] - self.timestamps[0])
            # TODO: Check for zero division error  pylint: disable=fixme
        return self._fps

    @property
    @abstractmethod
    def shape(self) -> Tuple[int, ...]:
        """Shape of the data frames."""
        raise NotImplementedError

    @property
    def frame_format(self) -> FrameFormat:
        """Frame format of the recording."""
        return FrameFormat(self.dtype, self.fps, self.shape)

    @property
    def data(self) -> Frame:
        """Read the next frame from the file.

        Raises:
            StopIteration: If no line was read.

        Returns:
            Frame read from the file.
        """
        line = self._file_timestamp.readline()
        if not line:
            raise StopIteration

        return Frame(float(line), next(self._generator))

    def close(self) -> None:
        """Close the reader and all corresponding files."""
        self._file_timestamp.close()
        log.debug("%s: %s | Closed timestamps file.", type(self).__name__, self._file_timestamp_name.as_posix())
        self._generator.close()
        self._close()
        log.debug("%s: %s | Closed data file.", type(self).__name__, self._file_name.as_posix())

    def __enter__(self: "ReaderABC") -> "ReaderABC":
        log.debug("%s: %s | Entered context manager.", type(self).__name__, self._file_name.as_posix())
        return self

    def __exit__(
        self,
        exc_type: Optional[Type[BaseException]],
        exc_value: Optional[BaseException],
        traceback: Optional[TracebackType],
    ) -> None:
        self.close()
        log.debug("%s: %s | Exited context manager.", type(self).__name__, self._file_name.as_posix())

    def __iter__(self: "ReaderABC") -> "ReaderABC":
        log.debug("%s: %s | Starting iterator to read file data.", type(self).__name__, self._file_name.as_posix())
        return self

    def __next__(self) -> Frame:
        return self.data

    def __len__(self) -> int:
        if not hasattr(self, "_len"):
            with open(self._file_timestamp.name, "r", encoding="utf-8") as file:
                self._len = sum(1 for _ in file)
        return self._len

    @abstractmethod
    def _open(self) -> None:
        raise NotImplementedError

    @abstractmethod
    def _init_data_generator(self) -> Generator[Any, None, None]:
        raise NotImplementedError

    @abstractmethod
    def _close(self) -> None:
        raise NotImplementedError

    @property
    def timestamps(self) -> List[float]:
        """All timestamps of the recording."""
        if not hasattr(self, "_timestamps"):
            with open(self._file_timestamp.name, "r", encoding="utf-8") as file:
                self._timestamps = [float(t) for t in file]
        return self._timestamps
