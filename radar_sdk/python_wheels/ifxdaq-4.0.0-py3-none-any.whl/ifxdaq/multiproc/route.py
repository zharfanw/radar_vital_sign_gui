"""Multiprocessing routing utils to enable data routing (data forwarding) in a background thread."""

from __future__ import annotations

import multiprocessing as mp
import queue
from typing import TYPE_CHECKING, Any, Dict, Optional

from ifxdaq.multiproc.abc import ThreadABC, WorkerABC

if TYPE_CHECKING:
    from ifxdaq.sensor.abc import Frame, SensorABC

__all__ = ["RouterWorker"]


class RouterThread(ThreadABC):
    """Thread to route data to other processes.

    Args:
        route_queue: Queue to forward the data.
    """

    def __init__(
        self,
        router_queue: "mp.SimpleQueue[Dict[str, Optional[Frame]]]",
        **kwargs: Any,
    ) -> None:
        super().__init__(**kwargs)
        self._router_queue = router_queue

    def _run(self) -> None:
        """Run the router thread in a separate thread."""
        while not self._stop_event.is_set():
            try:
                frame = self._queue.get(timeout=0.1)
            except queue.Empty:
                continue
            if not self._router_queue.empty():
                continue

            self._router_queue.put(frame)

        while not self._queue.empty():
            self._queue.get()


class RouterWorker(WorkerABC):
    """Worker to route data to other processes."""

    def __init__(self) -> None:
        super().__init__()
        self._queue: "mp.SimpleQueue[Dict[str, Optional[Frame]]]" = mp.SimpleQueue()

    @property
    def queue(self) -> "mp.SimpleQueue[Dict[str, Optional[Frame]]]":
        """Queue with frames."""
        return self._queue

    def _init_thread(self, device: SensorABC) -> RouterThread:
        return RouterThread(self._queue)

    def close(self) -> None:
        """Close the worker thread."""
        super().close()
        while not self._queue.empty():
            self._queue.get()

    def __iter__(self: "RouterWorker") -> "RouterWorker":
        self.start()
        return self

    def __next__(self) -> Dict[str, Optional[Frame]]:
        return self._queue.get()
