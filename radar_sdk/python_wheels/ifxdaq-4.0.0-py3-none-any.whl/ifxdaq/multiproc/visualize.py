"""Multiprocessing visualization utils to enable visualizations in a background thread."""

from __future__ import annotations

import multiprocessing as mp
import queue
from typing import TYPE_CHECKING, Any, Tuple

import cv2
import numpy as np

from ifxdaq.multiproc.abc import ThreadABC, WorkerABC

if TYPE_CHECKING:
    from ifxdaq.sensor.abc import SensorABC

__all__ = ["VisualizationWorker"]


class VisualizationThread(ThreadABC):
    """Thread to visualize data.

    Args:
        queue: Queue to forward the visualized data.
        sensor: Name of the sensor class.
        device_id: Device ID of the sensor.
        max_size: Maximum size of the visualizations. If the data is bigger, it will be downscaled.
        **kwargs: Keyword parameters for the Thread initialization.
    """

    def __init__(
        self,
        vis_queue: "mp.SimpleQueue[np.ndarray]",
        sensor: str,
        device_id: str,
        max_size: Tuple[int, int] = (240, 320),
        **kwargs: Any,
    ) -> None:
        super().__init__(**kwargs)
        self._vis_queue = vis_queue
        self._cls = sensor
        self._device_id = device_id
        self._max_h, self._max_w = max_size

    def _run(self) -> None:
        """Run the visualizations in a separate thread."""
        while not self._stop_event.is_set():
            try:
                frame = self._queue.get(timeout=0.1)
            except queue.Empty:
                continue
            if not self._vis_queue.empty():
                continue

            img = None
            if "radar" in frame and frame["radar"] is not None:
                img = self._visualize_radar(frame["radar"].data)
            elif "rgb" in frame and frame["rgb"] is not None:
                img = frame["rgb"].data

            if img is None:
                continue

            if img.shape[0] > self._max_h or img.shape[1] > self._max_w:
                img = self._resize(img)
            if len(img.shape) == 2:
                img = img[..., None]  # Add dummy channel for BW data

            assert img is not None
            self._vis_queue.put(img)

        while not self._queue.empty():
            self._queue.get()

    def _resize(self, img: np.ndarray) -> np.ndarray:
        # pylint: disable=invalid-name
        h, w = img.shape[:2]

        if w / self._max_w > h / self._max_h:
            img = cv2.resize(img, None, fx=self._max_w / img.shape[1], fy=self._max_w / img.shape[1])
        else:
            img = cv2.resize(img, None, fx=self._max_h / img.shape[0], fy=self._max_h / img.shape[0])

        return img

    @staticmethod
    def _visualize_radar(x_radar: np.ndarray) -> np.ndarray:
        x_radar = (x_radar[0, 0] / 4095.0).astype(np.float32)
        x_radar = x_radar - x_radar.mean(axis=-1, keepdims=True)
        x_range = np.fft.fft(x_radar, axis=-1)  # Range FFT
        x_range = x_range[..., : x_radar.shape[-1] // 2]  # Real data is symmetric
        x_mti = x_range - x_range.mean(axis=-2, keepdims=True)
        x_rdi = np.fft.fft(x_mti, axis=-2)  # Doppler FFT
        x_rdi = np.fft.fftshift(x_rdi, axes=-2)  # Swap spectrum
        rdi = np.abs(x_rdi)

        rdi -= rdi.min()
        rdi /= rdi.max()
        rdi = 255 * rdi
        return np.ascontiguousarray(rdi, dtype=np.uint8)


class VisualizationWorker(WorkerABC):
    """Worker to handle data visualizations.

    Args:
        max_size: Maximum size of the visualizations. If the data is bigger, it will be downscaled.
    """

    def __init__(self, max_size: Tuple[int, int] = (240, 320)) -> None:
        super().__init__()
        self._max_size = max_size
        self._queue: "mp.SimpleQueue[np.ndarray]" = mp.SimpleQueue()

    @property
    def queue(self) -> "mp.SimpleQueue[np.ndarray]":
        """Queue with visualizations."""
        return self._queue

    def _init_thread(self, device: SensorABC) -> VisualizationThread:
        return VisualizationThread(self._queue, type(device).__name__, device.device_id, self._max_size)

    def close(self) -> None:
        """Close the worker thread."""
        super().close()
        while not self._queue.empty():
            self._queue.get()
