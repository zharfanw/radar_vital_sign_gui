"""Multiprocessing recording utils to enable recordings in a background thread."""

from __future__ import annotations

import multiprocessing as mp
import queue
from pathlib import Path
from typing import TYPE_CHECKING, Any, Dict

from ifxdaq.multiproc.abc import ThreadABC, WorkerABC
from ifxdaq.record import DataRecorder

if TYPE_CHECKING:
    from ifxdaq.custom_typing import _PathLike
    from ifxdaq.sensor.abc import FrameFormat, SensorABC

__all__ = ["RecordingWorker"]


class RecordingThread(ThreadABC):
    """Thread to record data in the background.

    Args:
        file_name: Path to store the data.
        meta_data: Device dependent meta data to store.
        frame_format: The frame format of all streams of the used sensor.
        config_file: Configuration file to store.
        **kwargs: Keyword parameters for the Thread initialization.

    See Also:
        * :class:`~ifxdaq.fileio.core.Recorder`
    """

    def __init__(
        self,
        file_name: _PathLike,
        frame_format: Dict[str, FrameFormat],
        meta_data: Dict[str, str],
        config_file: _PathLike,
        **kwargs: Any,
    ) -> None:
        super().__init__(**kwargs)
        self._file_name = Path(file_name)
        self._fmt = frame_format
        self._meta = meta_data
        self._cfg = config_file

    def _run(self) -> None:
        """Run the recording in a separate thread."""
        with DataRecorder(self._file_name, frame_format=self._fmt, meta_data=self._meta, config_file=self._cfg) as rec:
            while not self._stop_event.is_set() or self._queue.qsize() > 0:
                try:
                    frame = self._queue.get(timeout=1)
                except queue.Empty:
                    pass
                else:
                    rec.write(frame)


class RecordingWorker(WorkerABC):
    """Worker to handle data recording."""

    def __init__(self) -> None:
        super().__init__()
        self._control_queue: "mp.SimpleQueue[str]" = mp.SimpleQueue()

    def start_recording(self, file_name: _PathLike) -> None:
        """Start a recording in the background process.

        Args:
            file_name: The recording is stored there.
        """
        if not self.is_active and not self._start_event.is_set():
            self._control_queue.put(Path(file_name).as_posix())
        super().start()

    def _init_thread(self, device: SensorABC) -> RecordingThread:
        file_name = self._control_queue.get()
        return RecordingThread(file_name, device.frame_format, device.meta_data, device.config_file)
