"""Multiprocessing utils base classes."""

from __future__ import annotations

import logging
import multiprocessing as mp
import queue
import threading
from abc import ABC, abstractmethod
from typing import TYPE_CHECKING, Any, Dict, Optional

if TYPE_CHECKING:
    from ifxdaq.sensor.abc import Frame, SensorABC

log = logging.getLogger(__name__)


class ThreadABC(threading.Thread, ABC):
    """Abstract base class for data handling threads.

    Implementations of threads to handle data in the background.

    * Separate data acquisition from data handling logically (also the implementations).
    * Data handling does not block the main process -> Avoids frame drops.
    * Queue to buffer frames -> Data handling can be slower than acquisition for some time.

    The individual threads will be wrapped in different :class:`~ifxdaq.multiproc.abc.WorkerABC` that allow the
    initialization from a different process.
    """

    def __init__(self, **kwargs: Any) -> None:
        super().__init__(None, **kwargs)
        self._queue: "queue.Queue[Dict[str, Optional[Frame]]]" = queue.Queue()
        self._stop_event = threading.Event()

    @property
    def queue(self) -> "queue.Queue[Dict[str, Optional[Frame]]]":
        """Queue to feed data to the thread."""
        return self._queue

    def close(self) -> None:
        """Stop the thread."""
        if not self._stop_event.is_set():
            self._stop_event.set()
            log.debug("%s | Triggered closing of thread.", type(self).__name__)

    def run(self) -> None:
        log.debug("%s | Enter run().", type(self).__name__)
        self._run()
        log.debug("%s | Quit run().", type(self).__name__)

    @abstractmethod
    def _run(self) -> None:
        """Run the handling of the data in a separate thread."""
        raise NotImplementedError


class WorkerABC(ABC):
    """Abstract base class for workers that handle data in separate threads.

    Implementations of workers that act as interface between the main process and background threads in other processes.

    Workers are attached to a :class:`~ifxdaq.process.SensorProcess`. From this process workers initialize background
    threads to allow continuous data acquisition. Workers are also an interface to communicate between the main process
    and the worker threads in the :class:`~ifxdaq.process.SensorProcess`.
    """

    def __init__(self) -> None:
        self._state = mp.Event()
        self._start_event = mp.Event()
        self._stop_event = mp.Event()
        self._thread: Optional[ThreadABC] = None

    @property
    def name(self) -> str:
        """Name of the worker (Classname without 'worker' in small letters)."""
        return type(self).__name__.lower().replace("worker", "")

    @property
    def is_active(self) -> bool:
        """Activity of the worker."""
        return self._state.is_set()

    def start(self) -> None:
        """Start the worker in the background process."""
        if not self.is_active and not self._start_event.is_set():
            self._start_event.set()
            log.debug("%s | Triggered start of worker.", type(self).__name__)

    def stop(self) -> None:
        """Stop the worker in the background process."""
        if self.is_active and not self._stop_event.is_set():
            self._stop_event.set()
            log.debug("%s | Triggered stop of worker.", type(self).__name__)

    def join(self) -> None:
        """Wait until the worker thread terminates."""
        if self._thread is not None:
            self._thread.join()

    @abstractmethod
    def _init_thread(self, device: SensorABC) -> ThreadABC:
        raise NotImplementedError

    def close(self) -> None:
        """Close the worker thread."""
        if self._thread is not None:
            self._thread.close()
            if not self._thread.is_alive():
                self._state.clear()
                self._stop_event.clear()
                self._thread = None
                log.debug("%s | Worker thread closed.", type(self).__name__)

    def process(self, frame: Dict[str, Optional[Frame]], device: SensorABC) -> None:
        """Start a thread, feed data, or stop the thread."""
        if self._thread is None:
            if self._start_event.is_set():
                self._thread = self._init_thread(device)
                self._thread.start()
                self._state.set()
                self._start_event.clear()
                self._thread.queue.put(frame)
        else:
            if self._stop_event.is_set():
                self.close()
            else:
                self._thread.queue.put(frame)
