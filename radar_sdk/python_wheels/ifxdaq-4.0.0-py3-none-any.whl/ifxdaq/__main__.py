"""This is the main entry to ifxdaq when it is called and not imported.

This means that if someone will call

.. code-block:: bash

    python -m ifxdaq

will start from this file.

When ifxdaq will be imported

    >>> import ifxdaq

then this file is ignored and the __init__.py file is used.
"""

from __future__ import annotations

import click

from ifxdaq import __version__
from ifxdaq.ai.commands import cmd_label
from ifxdaq.recorder.commands import cmd_recorder


@click.group(name="ifxdaq", context_settings={"help_option_names": ["-h", "--help"]})
@click.version_option(version=__version__)
def cli() -> None:
    """CLI tool of ifxdaq."""


@click.command("sysinfo")
def cmd_sysinfo() -> None:
    """Display the ifxdaq version and system/environment information."""
    # pylint: disable=import-outside-toplevel
    import pkg_resources

    from ifxdaq.utils.common import system_information

    print(*[f"{k.replace('_', ' ').title()}: {v}" for k, v in system_information().items()], sep="\n")
    print(
        "Packages:",
        *[f"    {pkg}" for pkg in sorted(pkg_resources.working_set, key=lambda pkg: pkg.project_name)],
        sep="\n",
    )


cli.add_command(cmd_recorder)
cli.add_command(cmd_label)
cli.add_command(cmd_sysinfo)

if __name__ == "__main__":
    cli()
