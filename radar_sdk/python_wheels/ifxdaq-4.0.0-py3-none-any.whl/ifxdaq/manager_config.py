"""Data structures and configurations for the sensor manager."""

from __future__ import annotations

import logging
from dataclasses import dataclass, field
from pathlib import Path
from typing import TYPE_CHECKING, Dict, Optional, Type

from omegaconf import DictConfig, OmegaConf

from ifxdaq.utils.common import fullname

if TYPE_CHECKING:
    from ifxdaq.custom_typing import _PathLike
    from ifxdaq.process import SensorProcess
    from ifxdaq.sensor.abc import SensorABC

log = logging.getLogger(__name__)

# OmegaConf / hydra convention starts with underscore:
# pylint: disable=protected-access

__all__ = ["SensorConfig", "Sensor", "ManagerConfig"]


@dataclass
class SensorConfig:
    r"""Data class containing the configuration for a sensor.

    This configuration structure is read from a `.yaml` file. It is one section
    corresponding to a single sensor.

    Note:
        The name `_target_` is chosen to ensure future compatibility of our
        configuration format with Facebook's configuration framework `Hydra`.

    Examples:
        Exemplary configuration section:

        .. code-block:: yaml

            RadarIfxAvian_00:
              _target_: ifxdaq.sensor.radar_ifx.RadarIfxAvian
              device_id: 000000000000000000006f6b745f3131
              config_file: C:\Workspace\RadarIfxAvian_00.json

    See Also:
        * :class:`Sensor`
        * :class:`ManagerConfig`

    .. autoattribute:: _target_
    """
    _target_: str
    """The sensors data class."""
    device_id: str
    """The device ID of the sensor."""
    config_file: Optional[str]
    """The file used to configure the sensor."""


@dataclass
class Sensor:
    """Data class containing the runtime information of a sensor.

    See Also:
        * :class:`SensorConfig`
        * :class:`ManagerConfig`
    """

    cls: Type[SensorABC]
    """The sensors class."""
    device_id: str
    """The device ID of the sensor."""
    config_file: Optional[Path] = None
    """The file used to configure the sensor."""
    process: Optional[SensorProcess] = None
    """Process handler of the sensor."""

    @property
    def config(self) -> SensorConfig:
        """Configuration of the sensor."""
        return SensorConfig(
            fullname(self.cls), self.device_id, None if self.config_file is None else self.config_file.as_posix()
        )

    @config.setter
    def config(self, config: SensorConfig) -> None:
        """Set the configuration of the sensor."""
        if fullname(self.cls) == config._target_ and self.device_id == config.device_id:
            self.config_file = Path(config.config_file) if config.config_file is not None else None
        else:
            raise RuntimeError("Configuration does not match with the sensor.")


@dataclass
class ManagerConfig:
    r"""Data class containing the configuration for a sensor manager.

    The configuration can be read from and written to a `.yaml` file. Each
    sensor has an own section, where its configuration is stored in a
    :class:`SensorConfig` object.

    Note:
        To ensure future compatibility, we introduce a hierarchy level for the
        sensors. In the future, more information can be added on top-level.

    Examples:
        Exemplary configuration file:

        .. code-block:: yaml

            Sensors:
              CamIntelRealSense_00:
                _target_: ifxdaq.sensor.camera_irs.CamIntelRealSense
                device_id: '035322250560'
                config_file: C:\Workspace\CamIntelRealSense_00.json
              RadarIfxAvian_00:
                _target_: ifxdaq.sensor.radar_ifx.RadarIfxAvian
                device_id: 000000000000000000006f6b745f3131
                config_file: C:\Workspace\RadarIfxAvian_00.json
              RadarIfxAvian_01:
                _target_: ifxdaq.sensor.radar_ifx.RadarIfxAvian
                device_id: '00000000000000000000000000303134'
                config_file: C:\Workspace\RadarIfxAvian_01.json

    See Also:
        * :class:`SensorConfig`
    """
    sensors: Dict[str, SensorConfig] = field(default_factory=dict)
    """Structure containing the configurations of individual sensors"""

    def __init__(self, sensors: Optional[DictConfig] = None) -> None:
        if sensors is None:
            sensors = OmegaConf.structured(ManagerConfig)
        self.sensors = sensors["sensors"]

    @classmethod
    def from_config_file(cls, config_file: _PathLike) -> "ManagerConfig":
        """Instantiate a configuration from a configuration file."""
        config = OmegaConf.load(config_file)
        config = OmegaConf.merge(cls, config)  # Validate config
        assert isinstance(config, DictConfig)
        log.debug("Loaded configuration from %s.", config_file)
        return cls(config)

    def dump(self, file: _PathLike) -> None:
        """Dump the configuration."""
        OmegaConf.save(self, file)

    def __contains__(self, sensor: Sensor) -> bool:
        try:
            self.get_name(sensor)
        except LookupError:
            return False
        return True

    def add(self, sensor: Sensor) -> str:
        """Add a sensor to the configuration.

        Args:
            sensor: Sensor instance.

        Raises:
            RuntimeError: If the device was already added.

        Returns:
            Name of the added sensor.
        """
        if sensor in self:
            raise RuntimeError(f"{fullname(sensor.cls)}|{sensor.device_id}: Device exists already.")
        name = self._generate_name(sensor)
        self.sensors[name] = sensor.config
        return name

    def set_config(self, name: str, config: SensorConfig) -> None:
        """Set the configuration of a sensor.

        Args:
            name: Name of the sensor.
            config: Corresponding configuration.

        Raises:
            LookupError: If the sensor is not connected.
        """
        if name not in self.sensors:
            raise LookupError(f"{name} not in configuration.")
        self.sensors[name] = config

    def get_config(self, name: str) -> SensorConfig:
        """Get the configuration of a sensor.

        Args:
            name: Name of the sensor.

        Raises:
            LookupError: If no configuration was found for sensor `name`.

        Returns:
            Sensor configuration object.
        """
        if name not in self.sensors:
            raise LookupError(f"{name} not in configuration.")
        return self.sensors[name]

    def get_name(self, sensor: Sensor) -> str:
        """Find a sensor in the configuration and return its name.

        Args:
            sensor: Sensor instance.

        Raises:
            LookupError: If `sensor` does not exist in device list.

        Returns:
            Name of the sensor.
        """
        device_type = fullname(sensor.cls)
        device_id = sensor.device_id
        for device_name, cfg in self.sensors.items():
            if cfg._target_ == device_type and cfg.device_id == device_id:
                return device_name
        raise LookupError(f"{device_type}|{device_id}: Device not in configuration.")

    def _generate_name(self, sensor: Sensor) -> str:
        """Generate a name (sensor type + running number) for a sensor."""
        i = 0
        while True:
            name = f"{sensor.cls.__name__}_{i:02}"
            if name in self.sensors:
                i += 1
                continue
            log.debug("%s: %s | Generated sensor name %s.", sensor.cls.__name__, sensor.device_id, name)
            return name
