"""Custom types."""

from __future__ import annotations

import pathlib
from typing import Union

_PathLike = Union[str, pathlib.Path]
