"""Logging utils for the recorder."""

from __future__ import annotations

from logging import Formatter, Handler, LogRecord

from PySide6.QtCore import QObject, Signal


class Signaller(QObject):  # pylint: disable=too-few-public-methods
    """Logging signaller."""

    new_record = Signal(object)


class PySideHandler(Handler):
    """Logging handler for PySide."""

    def __init__(self) -> None:
        super().__init__()
        self.signals = Signaller()

    def emit(self, record: LogRecord) -> None:
        """Emit the log record."""
        msg = self.format(record)
        self.signals.new_record.emit(msg)


class PySideFormatter(Formatter):
    """Logging formatter for PySide."""

    def format(self, record: LogRecord) -> str:
        """Format the log record."""
        formatted = super().format(record)
        if record.exc_text:
            formatted = formatted.replace("\n", "")
        return formatted
