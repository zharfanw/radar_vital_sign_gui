"""The recorder tool."""

from __future__ import annotations

from logging import getLogger
from pathlib import Path
from typing import TYPE_CHECKING, Iterable, Optional, Type

from PySide6.QtCore import QCoreApplication, Qt, Slot
from PySide6.QtWidgets import QApplication

from ifxdaq.errors import SensorError
from ifxdaq.manager import SensorManager
from ifxdaq.recorder.frame_handling import FrameHandler
from ifxdaq.recorder.view.main_window import MainWindow
from ifxdaq.recorder.view.sensor_widget import SensorInfo

if TYPE_CHECKING:
    from ifxdaq.multiproc.abc import WorkerABC
    from ifxdaq.recorder.gui_logging import PySideHandler

log = getLogger(__name__)


class GUIError(Exception):
    """Exception used if an error occurs within th application."""


class RecordingTool(QApplication):  # pylint: disable=too-few-public-methods
    """Application main class.

    Holds references to top level classes like model, controller, view (main window).

    Args:
        sensors: Sensors to use. List of module names, e.g. `ifxdaq.sensor.radar_ifx.RadarIfxAvian`.
        workers: Workers to use. List of classes, e.g. `RecordingWorker`.
        config_file_path: Path to the application's configuration file.
        logging_handler: Logging handler.
        preview: Enables/disables visualization area.
    """

    def __init__(  # pylint: disable=too-many-arguments
        self,
        sensors: Iterable[str],
        workers: Iterable[Type[WorkerABC]],
        config_file_path: Path,
        logging_handler: PySideHandler,
        preview: bool,
    ) -> None:
        log.debug("Starting GUI.")
        QCoreApplication.setAttribute(Qt.AA_ShareOpenGLContexts)
        super().__init__()
        self._logging_handler: PySideHandler = logging_handler
        self._main_window: MainWindow = MainWindow(preview=preview)
        self._sensor_manager: SensorManager = SensorManager(sensors, workers, config_file_path)
        self._frame_handler: FrameHandler = FrameHandler()
        self._connect_signals()
        self._main_window.show()

    def _connect_signals(self) -> None:
        """Connect application level signals."""
        self._logging_handler.signals.new_record.connect(self._main_window.on_message)
        self._main_window.discovery_triggered.connect(self._on_discovery_triggered)
        self._main_window.start_recording_clicked.connect(self._start_recording)
        self._main_window.stop_recording_clicked.connect(self._stop_recording)
        self._main_window.closed.connect(self._on_window_close)
        self._frame_handler.frame_ready.connect(self._main_window.on_frame)

    @Slot()
    def _on_discovery_triggered(self) -> None:
        self._sensor_manager.discover()
        self._main_window.set_discovered_sensors(
            [SensorInfo(name, str(sensor.config_file)) for name, sensor in sorted(self._sensor_manager.sensors.items())]
        )

    @Slot()
    def _start_recording(self) -> None:
        try:
            self._configure_sensors_or_raise()
            self._start_recording_or_raise()
            self._execute_recording_or_raise()
        except GUIError:
            log.error("Failed to start a recording.")

    def _configure_sensors_or_raise(self) -> None:
        for name, config_file in self._main_window.selected_sensors:
            if config_file == "":
                self._on_error("No configuration file selected.")

            try:
                self._sensor_manager.configure(name, Path(config_file))
            except FileNotFoundError as excp:
                self._on_error(f"Configuration file for {name} does not exist.", excp)
            except IsADirectoryError as excp:
                self._on_error(f"Configuration file for {name} is a directory.", excp)

    def _start_recording_or_raise(self) -> None:
        for name, _ in self._main_window.selected_sensors:
            try:
                process = self._sensor_manager.start(name)
                if process.visualization is not None:
                    self._frame_handler.register_queue(name, process.visualization.queue)
            except TimeoutError as excp:
                self._on_error(f"Failed to start {name} due to a timeout.", excp)
            except SensorError as excp:
                self._on_error(f"Failed to start {name} due to an internal error.", excp)

    def _execute_recording_or_raise(self) -> None:
        self._frame_handler.start()
        try:
            self._sensor_manager.start_recording(Path(self._main_window.current_output_directory))
            self._sensor_manager.start_visualization()
        except SensorError as excp:
            self._on_error("Recording was interrupted due to an internal error.", excp)

    @Slot()
    def _stop_recording(self) -> None:
        self._sensor_manager.stop_recording()
        self._sensor_manager.stop_visualization()
        self._frame_handler.stop()
        self._sensor_manager.close_all()
        self._frame_handler.reset()

    @Slot()
    def _on_window_close(self) -> None:
        self._stop_recording()
        self._sensor_manager.shutdown()
        log.debug("Closed GUI.")

    def _on_error(self, message: str, excp: Optional[Exception] = None) -> None:
        """Error popup."""
        self._stop_recording()
        log.error(message)
        if excp:
            log.debug(excp, exc_info=True)
        self._main_window.on_error(message)
        raise GUIError
