"""CLI commands for tools."""

from __future__ import annotations

import logging
import sys
from logging.handlers import RotatingFileHandler
from pathlib import Path
from typing import TYPE_CHECKING, List, Type

import click

from ifxdaq import get_cache_dir
from ifxdaq.multiproc.record import RecordingWorker

if TYPE_CHECKING:
    from ifxdaq.multiproc.abc import WorkerABC


@click.command(name="recorder", context_settings={"max_content_width": 120, "show_default": True})
@click.option("--config-file", default=get_cache_dir() / "config.yaml", help="Configuration file.", type=Path)
@click.option(
    "--vis/--no-vis",
    default=True,
    help="Enable visualizations. (Warning: This can lead to frame drops.)",
)
@click.option(
    "--webcam/--no-webcam",
    default=False,
    help="Enable webcams. (Warning: This can cause side effects on other cameras used.)",
)
@click.option(
    "--log-level",
    default="INFO",
    help="Log level.",
    type=click.Choice(["DEBUG", "INFO", "WARN", "ERROR"], case_sensitive=False),
)
def cmd_recorder(config_file: Path, vis: bool, webcam: bool, log_level: str) -> None:
    """Recorder tool."""
    # pylint: disable=import-outside-toplevel, too-many-locals
    from ifxdaq.multiproc.visualize import VisualizationWorker
    from ifxdaq.recorder.application import RecordingTool
    from ifxdaq.recorder.gui_logging import PySideHandler

    log_dir = get_cache_dir() / "logs"
    log_dir.mkdir(exist_ok=True, parents=True)

    formatter = logging.Formatter(
        "[%(asctime)s.%(msecs)03d PID:%(process)5d TID:%(thread)5d %(levelname)s %(name)s]: %(message)s",
        datefmt="%H:%M:%S",
    )
    _log = logging.getLogger("ifxdaq")
    _log.setLevel(logging.DEBUG)

    stream_handler = logging.StreamHandler(sys.stdout)
    stream_handler.setFormatter(formatter)
    stream_handler.setLevel(logging.DEBUG)
    _log.addHandler(stream_handler)
    file_handler = RotatingFileHandler(log_dir / "recorder.log", "w", 2**20, 5, "utf-8", delay=False)
    file_handler.setFormatter(formatter)
    file_handler.setLevel(logging.DEBUG)
    _log.addHandler(file_handler)
    gui_handler = PySideHandler()
    gui_handler.setFormatter(formatter)
    gui_handler.setLevel(log_level)
    _log.addHandler(gui_handler)

    sensors = [
        "ifxdaq.sensor.radar_ifx.RadarIfxBGT60TR13C",
        "ifxdaq.sensor.radar_ifx.RadarIfxBGT60UTR13D",
        "ifxdaq.sensor.radar_ifx.RadarIfxBGT60ATR24C",
        "ifxdaq.sensor.camera_irs.CamIntelRealSense",
    ]
    if webcam:
        sensors.append("ifxdaq.sensor.camera_ocv.CamOpenCV")
    workers: List[Type[WorkerABC]] = [RecordingWorker]
    if vis:
        workers.append(VisualizationWorker)

    app = RecordingTool(
        sensors=sensors, workers=workers, config_file_path=config_file, logging_handler=gui_handler, preview=vis
    )

    ret_val = app.exec_()

    for handler in _log.handlers:
        _log.removeHandler(handler)
        handler.close()

    sys.exit(ret_val)
