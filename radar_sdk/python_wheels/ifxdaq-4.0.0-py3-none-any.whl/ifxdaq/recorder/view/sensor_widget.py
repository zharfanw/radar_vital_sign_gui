"""SensorWidget to configure a sensor, show the configuration and select it for a recording."""
from collections import namedtuple
from pathlib import Path
from typing import Any

from PySide6.QtCore import QFile, Signal, Slot
from PySide6.QtUiTools import QUiLoader
from PySide6.QtWidgets import QFileDialog, QWidget

from ifxdaq.recorder.view.config_display_dialog import ConfigDisplayDialog

SensorInfo = namedtuple("SensorInfo", "name config_file")


class SensorWidget(QWidget):
    """SensorWidget."""

    def __init__(self, sensor_info: SensorInfo, is_selected: bool, *args: Any) -> None:
        super().__init__(*args)
        self._ui = self._load_ui(":/ui/sensor_widget.ui")
        self._initialize_ui(sensor_info, is_selected)
        self._connect_signals()

    def _load_ui(self, resource_path: str) -> QWidget:
        loader = QUiLoader(self)
        file = QFile(resource_path)
        if file.open(QFile.ReadOnly):  # type: ignore[call-overload]
            ui = loader.load(file)  # pylint: disable=invalid-name
            file.close()
            self.setLayout(ui.layout())
            return ui
        raise FileNotFoundError(f"Missing '{resource_path}'!")

    def _initialize_ui(self, sensor_info: SensorInfo, is_selected: bool) -> None:
        """Initialize main window."""
        self._ui.cbActive.setText(sensor_info.name)
        self._ui.cbActive.setChecked(is_selected)
        self._ui.eSensorConfigPath.setText(sensor_info.config_file)
        self._validate_path(sensor_info.config_file)

    def _connect_signals(self) -> None:
        """Connect main window level signals."""
        self._ui.bBrowse.clicked.connect(self._launch_output_directory_dialog)
        self._ui.bView.clicked.connect(self._launch_config_display_window)
        self._ui.eSensorConfigPath.textChanged.connect(self._validate_path)

    @property
    def toggled(self) -> Signal:
        """Checkbox toggle signal."""
        return self._ui.cbActive.stateChanged

    @property
    def is_selected(self) -> bool:
        """Select the sensor for a recording."""
        return self._ui.cbActive.isChecked()

    @property
    def current_config_path(self) -> str:
        """Current configuration file."""
        return self._ui.eSensorConfigPath.text()

    @Slot()
    def _launch_output_directory_dialog(self) -> None:
        options = QFileDialog.Options()
        options |= QFileDialog.DontUseNativeDialog
        path, _ = QFileDialog.getOpenFileName(parent=self, caption="Choose sensor config", dir="", options=options)
        if path:
            self._ui.eSensorConfigPath.setText(path)

    @Slot()
    def _launch_config_display_window(self) -> None:
        config_path = self._ui.eSensorConfigPath.text()
        dialog = ConfigDisplayDialog(config_path)
        dialog.exec()

    @Slot(str)
    def _validate_path(self, config_path: str) -> None:
        is_path_valid = Path(config_path).is_file()
        self._ui.bView.setEnabled(is_path_valid)
        self._ui.eSensorConfigPath.setStyleSheet("" if is_path_valid else "QLineEdit {; background-color: #FFCCCC;}")
        self._ui.eSensorConfigPath.setToolTip("" if is_path_valid else "The path does not point to an existing file")
