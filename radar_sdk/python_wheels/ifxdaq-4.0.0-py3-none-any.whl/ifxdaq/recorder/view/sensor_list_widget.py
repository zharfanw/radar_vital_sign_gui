"""Sensor list."""
from typing import Dict, List, Tuple

from PySide6.QtCore import SignalInstance
from PySide6.QtWidgets import QListWidget, QListWidgetItem, QWidget

from ifxdaq.recorder.view.sensor_widget import SensorInfo, SensorWidget


class SensorListWidget(QListWidget):
    """Widget to list all available sensor."""

    def __init__(self, parent: QWidget = None) -> None:
        super().__init__(parent=parent)
        self._sensor_widgets: Dict[str, SensorWidget] = {}
        self._items: Dict[str, QListWidgetItem] = {}

    @property
    def toggle_signals(self) -> List[SignalInstance]:
        """Return checkbox toggle signals for all sensors."""
        return [widget.toggled for _, widget in sorted(self._sensor_widgets.items())]

    @property
    def selected_sensors(self) -> List[Tuple[str, str]]:
        """Currently selected (via checkbox) devices."""
        return [
            (name, sensor_widget.current_config_path)
            for name, sensor_widget in self._sensor_widgets.items()
            if sensor_widget.is_selected
        ]

    def populate(self, sensor_infos: List[SensorInfo]) -> None:
        """Populate the list with available sensors."""
        selected_sensor_names = {selected[0] for selected in self.selected_sensors}
        self.clear()
        for sensor_info in sensor_infos:
            self.add_sensor(sensor_info, sensor_info.name in selected_sensor_names)

    def add_sensor(self, sensor_info: SensorInfo, is_selected: bool) -> None:
        """Add an individual sensors."""
        widget = SensorWidget(sensor_info=sensor_info, is_selected=is_selected)
        self._sensor_widgets[sensor_info.name] = widget
        item = QListWidgetItem(self)
        item.setSizeHint(widget.sizeHint())
        self._items[sensor_info.name] = item
        self.addItem(item)
        self.setItemWidget(item, widget)

    def clear(self) -> None:
        """Reset the list."""
        super().clear()
        self._items.clear()
        self._sensor_widgets.clear()
