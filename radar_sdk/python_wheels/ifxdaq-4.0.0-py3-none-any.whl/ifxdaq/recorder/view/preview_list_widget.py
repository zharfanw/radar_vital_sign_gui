"""Container widget for sensor previews."""
from typing import Callable, Dict, List

from PySide6.QtCore import Slot
from PySide6.QtGui import QPixmap
from PySide6.QtWidgets import QListWidget, QListWidgetItem, QWidget

from ifxdaq.recorder.view.preview_widget import PreviewWidget
from ifxdaq.recorder.view.sensor_widget import SensorInfo


class CustomQListWidgetItem(QListWidgetItem):  # pylint: disable=too-few-public-methods
    """List item with set_visible slot extension."""

    @Slot(bool)
    def set_visible(self, visible: bool) -> None:
        """Add function to toggle visibility."""
        self.setHidden(not visible)


class PreviewListWidget(QListWidget):
    """Widget to show all previews."""

    def __init__(self, parent: QWidget = None) -> None:
        super().__init__(parent=parent)
        self._items: Dict[str, QListWidgetItem] = {}
        self._preview_widgets: Dict[str, PreviewWidget] = {}

    @property
    def item_slots(self) -> List[Callable]:
        """Return visibility-slots for all sensors."""
        return [item.set_visible for _, item in sorted(self._items.items())]

    def populate(self, sensor_infos: List[SensorInfo], selected_sensors: List[str]) -> None:
        """Populate the widget with the available sensors."""
        self.clear()
        for sensor_info in sensor_infos:
            self.add_preview(sensor_info.name, sensor_info.name in selected_sensors)

    def add_preview(self, sensor_name: str, is_visible: bool) -> None:
        """Add a single preview for one sensor."""
        widget = PreviewWidget(sensor_name)
        self._preview_widgets[sensor_name] = widget
        item = CustomQListWidgetItem(self)
        item.setSizeHint(widget.sizeHint())
        self._items[sensor_name] = item
        self.addItem(item)
        self.setItemWidget(item, widget)
        item.set_visible(is_visible)

    def clear(self) -> None:
        """Reset the widget."""
        super().clear()
        self._items.clear()
        self._preview_widgets.clear()

    def display_frame(self, name: str, frame: QPixmap) -> None:
        """Update an individual preview.

        Args:
            name: Name of the sensor.
            frame: QPixmap to set.
        """
        item = self._items[name]
        if not item.isHidden():
            preview_widget = self._preview_widgets[name]
            preview_widget.set_preview(frame)
            item.setSizeHint(preview_widget.sizeHint())
