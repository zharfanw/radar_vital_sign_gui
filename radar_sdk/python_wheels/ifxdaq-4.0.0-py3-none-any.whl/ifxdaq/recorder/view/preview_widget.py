"""Preview for sensor data (name + visualization)."""
from typing import Any

from PySide6.QtCore import QFile
from PySide6.QtGui import QMouseEvent, QPixmap
from PySide6.QtUiTools import QUiLoader
from PySide6.QtWidgets import QWidget

from ifxdaq.recorder.view.preview_display_window import PreviewDisplayWindow


class PreviewWidget(QWidget):
    """PreviewWidget (name + visualization)."""

    def __init__(self, sensor_name: str, *args: Any) -> None:
        super().__init__(*args)
        self._ui = self._load_ui(":/ui/preview_widget.ui")
        self._preview_window = PreviewDisplayWindow(sensor_name=sensor_name, parent=self)
        self._initialize_ui(sensor_name)

    def _load_ui(self, resource_path: str) -> QWidget:
        loader = QUiLoader(self)
        file = QFile(resource_path)
        if file.open(QFile.ReadOnly):  # type: ignore[call-overload]
            ui = loader.load(file)  # pylint: disable=invalid-name
            file.close()
            self.setLayout(ui.layout())
            return ui
        raise FileNotFoundError(f"Missing '{resource_path}'!")

    def _initialize_ui(self, sensor_name: str) -> None:
        """Initialize main window."""
        self._ui.lLabel.setText(sensor_name)

    def set_preview(self, frame: QPixmap) -> None:
        """Update the preview with a new frame."""
        self._ui.lImage.setPixmap(frame.scaledToWidth(320))
        if self._preview_window.isVisible():
            self._preview_window.set_frame(frame)

    def mouseDoubleClickEvent(self, event: QMouseEvent) -> None:  # pylint: disable=invalid-name
        """Handle mouse clicks onto the preview."""
        self._preview_window.showFullScreen()
        super().mouseDoubleClickEvent(event)
