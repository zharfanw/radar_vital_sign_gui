"""YOLO module."""

from __future__ import annotations

import shutil
from pathlib import Path
from typing import TYPE_CHECKING, Any, Dict, List, Literal, Optional

import cv2
import numpy as np
from ultralytics import YOLO
from ultralytics.utils.downloads import attempt_download_asset

from ifxdaq import get_cache_dir
from ifxdaq.ai.utils import BoundingBox, Detection
from ifxdaq.utils.common import fullname

if TYPE_CHECKING:
    from contextlib import ExitStack

    from ultralytics.engine.results import Results


class YOLO8:  # pylint: disable=too-many-instance-attributes
    """YOLOv8 based object detection and Tracking.

    Args:
        model: Model to use.
        task: model typem, i.e. detector, segmentation, keypoints
        model_size: size of model to use from ultralytics zoo, trades precision vs inference time

            * ``yolov8n.pt``: Slim & fast.
            * ``yolov8s.pt``: Bigger & more accurate.
            * ``yolov8m.pt``: Bigger & more accurate.
            * ``yolov8l.pt``: Bigger & more accurate.
            * ``yolov8x.pt``: Largest & most accurate.

            * also allowable with suffix 'seg' and 'pose' before '.pt' extension

        threshold: Detection threshold of the model.
        nms: IoU threshold for the non-maximum suppression (nms).

    Raises:
        RuntimeError: N/A with YOLO8: If model initialization failed with the provided `weights`.
    """

    def __init__(  # pylint: disable=too-many-arguments
        self,
        model: str = "yolov8",
        task: Literal["det", "seg", "pose"] = "det",
        model_size: Literal["n", "s", "m", "l", "x"] = "n",
        classes: Optional[List[str]] = None,
        name: Optional[str] = None,
        threshold: float = 0.4,
        nms: float = 0.5,
    ) -> None:
        task = "" if str(task) == "det" else f"-{str(task)}"  # type: ignore[assignment]
        model = f"{model}{model_size}{task}.pt"
        self.weights = self.get_cached_weights(model)
        self.model: YOLO = YOLO(model=self.weights)
        self.iou = nms
        self.conf = threshold

        if classes is not None:
            self._classes = classes
        else:
            self._classes = self.model.names.values()
        self._context_stack: ExitStack
        self._name = name

        self.classes_lst = [key for key, value in self.model.names.items() if value in self._classes]

        self._config = {
            "model": model,
            "iou_threshold": nms,
            "conf_threshold": threshold,
        }

    @property
    def config(self) -> Dict[str, Any]:
        """Configuration of the algorithm."""
        return self._config

    @property
    def meta_data(self) -> Dict[str, Any]:
        """Algorithms meta data."""
        meta_data = {
            "algorithm_name": fullname(self.__class__),
            "algorithm_config": self.config,
        }
        return meta_data

    def __call__(self, image: np.ndarray) -> List[Detection]:
        """Call :meth:`.predict`: and run the inference engine on the inputs.

        Args:
            image: Image of the scene (RGB).

        Returns:
            The inferred information.
        """
        return self.predict(image)

    def track(self, file: Path) -> List[Results]:
        """Run Yolo Track on given video file.

        Args:
            file: path to video

        Returns:
            The inferred information.
        """
        results = self.model.track(
            source=file,
            tracker="botsort.yaml",
            verbose=False,
            conf=self.conf,
            iou=self.iou,
            show=False,
            stream=True,
            classes=self.classes_lst,
        )
        return results

    def get_predictions(self, results: Results) -> List[Detection]:
        """Process YOLO results to Detections.

        Args:
            results: YOLO Results.

        Returns:
            The inferred information.
        """
        predictions = []
        for result in results:
            box = result.boxes
            kpt = None
            if result.keypoints is not None:
                (kpt,) = result.keypoints.data.cpu().numpy()
            segmentation = None
            if result.masks is not None:
                mask = result.masks.cpu().numpy().data.astype(np.uint8)
                shape = result.orig_shape
                mask = cv2.resize(mask.squeeze(0), (shape[1], shape[0]))
                segmentation, _ = cv2.findContours(mask, cv2.RETR_TREE, cv2.CHAIN_APPROX_SIMPLE)
                segmentation = [[int(x) for x in seg.reshape(-1)] for seg in segmentation]
            annotation = Detection(
                cls=result.names[int(box.cls.cpu().numpy().squeeze())],
                confidence=float(box.conf),
                bbox=BoundingBox.from_tlbr(box.xyxy.squeeze().round().tolist()),
                track_id=int(box.id.cpu().numpy().squeeze().tolist()) if box.is_track else None,
                keypoints=kpt,
                segmentation=segmentation,
            )
            predictions.append(annotation)
        return predictions

    def predict(self, image: np.ndarray) -> List[Detection]:
        """Detect objects in an image.

        This function is bypassed

        Args:
            image: Image of the scene (RGB).

        Returns:
            List of detections (class, confidence, bounding box).
        """
        result: Results = self.model.predict(
            source=image, name="YOLOv8Seg", verbose=False, conf=self.conf, iou=self.iou
        )[0]

        return self.get_predictions(result)

    @staticmethod
    def get_cached_weights(model: str) -> Path:
        """Download weights or reuse existing weights from cache."""
        dst = get_cache_dir() / model
        if not dst.exists():
            weights = Path(attempt_download_asset(model))
            shutil.move(weights, dst)
        return dst
