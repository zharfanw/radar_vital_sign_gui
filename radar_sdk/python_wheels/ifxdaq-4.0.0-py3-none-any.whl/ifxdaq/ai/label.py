"""Module to load labels as different data types."""

from __future__ import annotations

import logging
from datetime import datetime
from pathlib import Path
from typing import TYPE_CHECKING, List, Tuple

import numpy as np
import pandas as pd

from ifxdaq.ai.utils import BoundingBox, Detection
from ifxdaq.utils.common import read_json

if TYPE_CHECKING:
    from ifxdaq.custom_typing import _PathLike

log = logging.getLogger(__file__)

__all__ = ["cartesian_to_spherical", "LabelLoader"]

# pylint: disable=too-few-public-methods


def cartesian_to_spherical(x_coord: float, y_coord: float, z_coord: float) -> Tuple[float, float, float]:
    """Convert cartesian coordinates to spherical.

    Args:
        x_coord: x-Coordinate.
        y_coord: y-Coordinate.
        z_coord: z-Coordinate.

    Returns:
        Point in spherical coordinates (radius, azimuth, elevation).
    """

    radius = np.sqrt(x_coord**2 + y_coord**2 + z_coord**2)
    elevation = np.arctan2((np.sqrt(x_coord**2 + y_coord**2)), z_coord)
    azimuth = np.arctan2(y_coord, x_coord)

    return radius, azimuth, elevation


class LabelLoader:
    """Load labels as pd.DataFrame."""

    _column_names: List[str] = []

    @staticmethod
    def _load_timestamps(label_dir: Path) -> pd.DatetimeIndex:
        """Load the timestamps from a file."""
        with open(label_dir / "label_timestamp.csv", "r", encoding="utf-8") as f_handle:
            timestamps = [datetime.utcfromtimestamp(float(line)) for line in f_handle.readlines()]
        timestamps = pd.to_datetime(timestamps)
        return timestamps

    @classmethod
    def to_dataframe(cls, label_dir: _PathLike) -> pd.DataFrame:
        """Load labels as dataframe.

        Args:
            label_dir: Directory with the labels.

        Returns:
            Labels as dataframe.

        Raises:
            KeyError: If file does not contain the required labels.
        """
        label_dir = Path(label_dir)
        raw_json_data = read_json(label_dir / "label.json")
        timestamps = cls._load_timestamps(label_dir)
        return cls._to_dataframe(timestamps, raw_json_data)

    @classmethod
    def _to_dataframe(cls, timestamps: pd.DatetimeIndex, raw_json_data: dict) -> pd.DataFrame:
        detection_list = []
        for timestamp, detections in zip(timestamps, raw_json_data):
            if not detections:
                detections = [
                    Detection(
                        cls=np.nan, confidence=np.nan, bbox=BoundingBox(np.nan, np.nan, np.nan, np.nan)  # type: ignore
                    ).to_dict()
                ]
            detection_list.extend([(timestamp, Detection.from_dict(det).to_pandas()) for det in detections])
        timestamps, detections = zip(*detection_list)
        dataframe = pd.DataFrame(data=detections, index=timestamps)
        dataframe.index.name = "timestamp"
        dataframe["range"], dataframe["azimuth"], dataframe["elevation"] = cartesian_to_spherical(
            dataframe["x"], dataframe["y"], dataframe["z"]
        )
        return dataframe
