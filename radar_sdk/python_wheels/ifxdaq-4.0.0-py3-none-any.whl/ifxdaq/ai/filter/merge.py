"""Merge consecutive tracks."""

from __future__ import annotations

import itertools
from abc import abstractmethod
from typing import Any, Callable, Dict, Tuple, Union

import numpy as np
import pandas as pd

from ifxdaq.ai.filter.abc import TrackFilterABC, get_unique_ids
from ifxdaq.ai.utils import BoundingBox

__all__ = ["ConcatBBoxFilter", "ConcatWorldFilter"]


class MergeFilterABC(TrackFilterABC):
    """Abstract base class for different merging filters.

    Args:
        threshold_metric: Threshold for the applied metric between two tracks.
    """

    def __init__(self, threshold_metric: float):
        self._threshold_metric = threshold_metric

    def process(self, tracks: pd.DataFrame) -> pd.DataFrame:
        """Identify and merge tracks that belong together.

        Args:
            tracks: DataFrame containing the tracks.

        Returns:
            Filtered DataFrame.
        """
        tracks = tracks.copy()

        if tracks.isna().values.all():  # Return empty (NaN) dataframe
            return tracks

        id_x, id_y = self._find_most_similar(tracks)

        if not np.isnan(id_x):  # Recursively merge the remaining tracks
            tracks.loc[tracks["id"] == id_y, "id"] = id_x
            tracks = self.process(tracks)
        else:  # End of recursion - Re-assign running track IDs
            track_ids = get_unique_ids(tracks)
            tracks["id"].replace(dict(zip(track_ids, range(len(track_ids)))), inplace=True)

        return tracks

    @abstractmethod
    def _find_most_similar(self, tracks: pd.DataFrame) -> pd.DataFrame:
        raise NotImplementedError


class ConcatFilter(MergeFilterABC):
    """Concatenate close tracks.

    Compares the start & end measurements of all track combinations according to a metric & merges them recursively,
    if they are below the thresholds within the time & metric.

    Args:
        threshold_metric: Threshold for the applied metric between two tracks.
        threshold_time: Maximum time between two tracks (in seconds).
    """

    def __init__(self, threshold_metric: float, threshold_time: float):
        super().__init__(threshold_metric)
        self._threshold_time = threshold_time

    @property
    def meta_data(self) -> Dict[str, Any]:
        """Filter meta data."""
        meta_data = {
            **super().meta_data,
            **{"parameter": {"threshold_metric": self._threshold_metric, "threshold_time": self._threshold_time}},
        }
        return meta_data

    @staticmethod
    def _calculate_track_costs(
        tracks: pd.DataFrame, metric: Callable[[pd.Series, pd.Series], float], threshold_time: float
    ) -> np.ndarray:
        track_ids = get_unique_ids(tracks)
        costs = np.full(2 * (len(track_ids),), np.NaN)

        for (i, id_x), (j, id_y) in itertools.product(enumerate(track_ids), repeat=2):
            if id_x >= id_y:  # Skip self-comparison & track x must start before track y
                continue
            # End of track x
            track_x = tracks[tracks["id"] == id_x].dropna(axis=0, how="all")
            timestamp_x = track_x.index[-1]
            meas_x = track_x.iloc[-1]
            # Start of track y
            track_y = tracks[tracks["id"] == id_y].dropna(axis=0, how="all")
            timestamp_y = track_y.index[0]
            meas_y = track_y.iloc[0]

            if meas_x["class"] != meas_y["class"]:
                continue

            if abs(timestamp_y - timestamp_x) < pd.Timedelta(threshold_time, unit="second"):
                costs[i, j] = metric(meas_x, meas_y)

        return costs

    @abstractmethod
    def _find_most_similar(self, tracks: pd.DataFrame) -> pd.DataFrame:
        raise NotImplementedError


class ConcatBBoxFilter(ConcatFilter):
    """Concatenate tracks based on the similarity of bounding boxes."""

    @staticmethod
    def _metric(measurement_x: pd.Series, measurement_y: pd.Series) -> float:
        bbox_x = BoundingBox.from_tlbr(
            np.asarray(measurement_x[["bbox_left", "bbox_top", "bbox_right", "bbox_bottom"]])
        )
        bbox_y = BoundingBox.from_tlbr(
            np.asarray(measurement_y[["bbox_left", "bbox_top", "bbox_right", "bbox_bottom"]])
        )
        return bbox_x.iou(bbox_y)

    def _find_most_similar(self, tracks: pd.DataFrame) -> Tuple[Union[float, str], Union[float, str]]:
        track_ids = get_unique_ids(tracks)
        similarity = self._calculate_track_costs(tracks, self._metric, self._threshold_time)
        similarity[similarity < self._threshold_metric] = np.NaN
        if np.isnan(similarity).all():  # No match
            return float("nan"), float("nan")
        similarity = pd.DataFrame(similarity, columns=track_ids, index=track_ids)
        return similarity.max(axis=1).idxmax(), similarity.max(axis=0).idxmax()


class ConcatWorldFilter(ConcatFilter):
    """Concatenate tracks based on the distance of world coordinates."""

    @staticmethod
    def _metric(measurement_x: pd.Series, measurement_y: pd.Series) -> float:
        world_x = measurement_x[["x", "y", "z"]]
        world_y = measurement_y[["x", "y", "z"]]
        return float(np.linalg.norm(world_x - world_y))

    def _find_most_similar(self, tracks: pd.DataFrame) -> Tuple[Union[float, str], Union[float, str]]:
        track_ids = get_unique_ids(tracks)
        distance = self._calculate_track_costs(tracks, self._metric, self._threshold_time)
        distance[distance > self._threshold_metric] = np.NaN
        if np.isnan(distance).all():  # No match
            return float("nan"), float("nan")
        distance = pd.DataFrame(distance, columns=track_ids, index=track_ids)
        return distance.min(axis=1).idxmin(), distance.min(axis=0).idxmin()
