"""Filter to smooth tracks."""

from __future__ import annotations

from typing import TYPE_CHECKING, Any, Dict

from scipy.signal import savgol_filter

from ifxdaq.ai.filter.abc import TrackFilterABC, get_unique_ids

if TYPE_CHECKING:
    import numpy as np
    import pandas as pd

__all__ = ["SavGolFilter"]


class SavGolFilter(TrackFilterABC):
    """Apply Savitzky-Golay filter to smooth selected components over time.

    Args:
        window_length: The length of the filter window.
        polyorder: The order of the polynomial used to fit the samples.

    Notes:
        See `scipy.signal.savgol_filter
        <https://docs.scipy.org/doc/scipy/reference/generated/scipy.signal.savgol_filter.html>`_ for more details on the
        parameters.

    Warning:
        The Savitzky-Golay filter assumes equally spaced data points. If the data points are not equally spaced, the
        performance of the filter will degrade.
    """

    def __init__(self, window_length: int, polyorder: int) -> None:
        super().__init__()
        self._window_length = window_length
        self._polyorder = polyorder

    @property
    def meta_data(self) -> Dict[str, Any]:
        """Filter meta data."""
        meta_data = {
            **super().meta_data,
            **{"parameter": {"window_length": self._window_length, "polyorder": self._polyorder}},
        }
        return meta_data

    def process(self, tracks: pd.DataFrame) -> pd.DataFrame:
        """Filter all tracks with a Savitzky-Golay filter.

        Args:
            tracks: DataFrame containing the tracks.

        Returns:
            Filtered DataFrame.
        """
        tracks = tracks.copy()
        numeric_columns = self._extract_numeric_columns(tracks)
        for track_id in get_unique_ids(tracks):
            tracks.loc[tracks["id"] == track_id, numeric_columns] = self._apply_savgol(
                tracks[tracks["id"] == track_id][numeric_columns], self._window_length, self._polyorder
            )

        return tracks

    @staticmethod
    def _apply_savgol(track: pd.DataFrame, window_length: int, polyorder: int) -> pd.DataFrame:
        """Apply Savitzky-Golay filter on a single track."""
        if len(track) < window_length:
            window_length = len(track)

        # Uneven window
        window_length = window_length if window_length % 2 else window_length - 1

        def filter_func(x: np.ndarray) -> np.ndarray:  # pylint: disable=invalid-name
            return savgol_filter(x, window_length=window_length, polyorder=polyorder, mode="interp")

        return track.apply(filter_func)
