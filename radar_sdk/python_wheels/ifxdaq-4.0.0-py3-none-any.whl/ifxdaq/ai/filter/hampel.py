"""Hampel filter to remove outliers."""

from __future__ import annotations

from typing import TYPE_CHECKING, Any, Dict

import numpy as np

from ifxdaq.ai.filter.abc import TrackFilterABC, get_unique_ids

if TYPE_CHECKING:
    import pandas as pd

__all__ = ["HampelOutlierFilter"]


def median_absolute_deviation(series: np.ndarray) -> float:
    """Calculate the median absolute deviation for the given series.

    Args:
        series: Input series.

    Returns:
        Median absolute deviation.
    """
    return np.median(np.abs(series - np.median(series)))


class HampelOutlierFilter(TrackFilterABC):
    """Outlier removal using Hampel identifier.

    The Hampel identifier is a variation of the three-sigma rule of statistics that is robust against outliers.
    Please have a look at https://de.mathworks.com/help/signal/ref/hampel.html for more details.

    Args:
        time_window: Window time (in seconds).
        n_sigma: Number of standard deviations.
    """

    def __init__(self, time_window: float, n_sigma: float) -> None:
        super().__init__()
        self._time_window = time_window
        self._n_sigma = n_sigma

    @property
    def meta_data(self) -> Dict[str, Any]:
        """Filter meta data."""
        meta_data = {
            **super().meta_data,
            **{"parameter": {"time_window": self._time_window, "n_sigma": self._n_sigma}},
        }
        return meta_data

    def process(self, tracks: pd.DataFrame) -> pd.DataFrame:
        """Filter all tracks with a hampel filter.

        Args:
            tracks: DataFrame containing the tracks.

        Returns:
            Filtered DataFrame.
        """
        tracks = tracks.copy()
        numeric_columns = self._extract_numeric_columns(tracks)
        for track_id in get_unique_ids(tracks):
            tracks.loc[tracks["id"] == track_id, numeric_columns] = self._apply_hampel(
                tracks[tracks["id"] == track_id][numeric_columns], self._time_window, self._n_sigma
            )

        return tracks

    @staticmethod
    def _apply_hampel(track: pd.DataFrame, window: float, n_sigma: float) -> pd.DataFrame:
        """Apply hampel filter on a single track.

        Args:
            track: Single track.
            window: Window size (in seconds).
            n_sigma: Number of standard deviations.

        Returns:
            Filtered track.
        """
        track = track.copy()
        # https://en.wikipedia.org/wiki/Median_absolute_deviation#Relation_to_standard_deviation
        k = 1.4826

        track_rolling = track.rolling(window=f"{window}s", center=True)

        rolling_median = track_rolling.median().bfill().ffill()
        rolling_mad = track_rolling.apply(median_absolute_deviation).bfill().ffill()
        rolling_sigma = k * rolling_mad

        outliers = np.abs(track - rolling_median) >= (n_sigma * rolling_sigma)
        track[outliers] = rolling_median[outliers]
        return track
