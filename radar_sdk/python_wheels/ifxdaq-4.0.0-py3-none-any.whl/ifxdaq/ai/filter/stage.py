"""Object detection stage module."""

from __future__ import annotations

from typing import TYPE_CHECKING, Any, Dict, List, Optional, Sequence

import numpy as np
from tqdm import tqdm

from ifxdaq.ai.filter.duplicate import DropDuplicateFilter, DuplicateBBoxFilter
from ifxdaq.ai.filter.fill import FillGapFilter
from ifxdaq.ai.filter.hampel import HampelOutlierFilter
from ifxdaq.ai.filter.merge import ConcatBBoxFilter
from ifxdaq.ai.filter.savgol import SavGolFilter
from ifxdaq.ai.filter.short import ShortTrackFilter
from ifxdaq.ai.label import LabelLoader
from ifxdaq.ai.stage_abc import StageABC
from ifxdaq.ai.utils import Detection
from ifxdaq.record import DataRecorder
from ifxdaq.sensor.abc import Frame, FrameFormat

if TYPE_CHECKING:
    from pathlib import Path

    from ifxdaq.ai.filter.abc import TrackFilterABC


class FilterStage(StageABC):
    """Filter stage.

    Filter detections to improve results.

    Args:
        filter_object: Filter instance.
        name: Optional individual name for the destination folder.
    """

    def __init__(self, filter_object: TrackFilterABC, name: Optional[str] = None) -> None:
        if name is None:
            name = type(filter_object).__name__
        super().__init__(name=name)
        self._filter = filter_object

    @property
    def stage_settings(self) -> Dict[str, Any]:
        """Provide individual meta-information of the stage."""
        return {"filter": self._filter.meta_data}

    def _process_single_recording(
        self, input_dir: Path, raw_data_dir: Path, destination_dir: Path, meta_data: Dict[str, Any]
    ) -> None:
        """Detect objects in a single recording and store the results.

        Notes:
            Since the detection module directly processes the raw camera recordings, `input_dir` and `raw_data_dir`
            should be identical.

        Args:
            input_dir: Directory which contains the raw camera data.
            raw_data_dir: Directory which contains the raw camera data.
            destination_dir: Directory where the detections are stored.
            meta_data: Dictionary which contains the meta information.
        """
        df_raw = LabelLoader.to_dataframe(input_dir)
        df_filtered = self._filter.process(df_raw)

        frame_format = {"label": FrameFormat(np.dtype("object"), -1, ())}  # -1, because frame rate is not required
        recorder = self._context_stack.enter_context(DataRecorder(destination_dir, frame_format, meta_data))
        filter_name = self.stage_settings["filter"]["filter_name"].split(".")[-1]

        for timestamp, detections in tqdm(
            df_filtered.groupby("timestamp"), desc=filter_name, unit="Frame", position=1, leave=False
        ):
            timestamp = timestamp.timestamp()  # Convert pd.Datetime into UNIX timestamp
            detections = [  # Convert pd.DataFrame to JSON serializable dict
                Detection.from_pandas(row).to_dict() for _, row in detections.iterrows() if not row.isna().all()
            ]
            recorder.write({"label": Frame(timestamp, detections)})


def merge_tracks(
    label: Sequence[Path],
    threshold_metric_concat: float,
    threshold_time_concat: float,
    threshold_metric_duplicate: float,
    output_name: Optional[str] = None,
) -> List[Path]:
    """Merge tracks in the given LABEL_DIR(s).

    First, consecutive tracks with different ID(s) that belong to the same person based on bounding box similarity are
    merged. Gaps between merged tracks are filled with a linear interpolation.
    In the second step, potential duplicated tracks are identified. Two tracks are considered as a duplicate, if the
    average similarity over all detections is above the specified threshold.
    In case there are multiple detections of one object in the same frame, the detection with the highest confidence
    score is used and all other detections will be removed.

    Args:
        label: Label dir(s) to process.
        threshold_metric_concat: Threshold for the applied metric between two consecutive tracks.
        threshold_time_concat: Maximum time between two consecutive tracks (in seconds).
        threshold_metric_duplicate: Threhsold for the applied metric between two intersecting tracks.
        output_name: Optional individual name for the output directory.

    Returns:
        List of folders with processed data.
    """
    engine = FilterStage(ConcatBBoxFilter(threshold_metric_concat, threshold_time_concat), name=output_name)
    label = engine.process_batch(label)
    engine = FilterStage(FillGapFilter(), name=output_name)
    label = engine.process_batch(label)
    engine = FilterStage(DuplicateBBoxFilter(threshold_metric_duplicate), name=output_name)
    label = engine.process_batch(label)
    engine = FilterStage(DropDuplicateFilter(), name=output_name)
    return engine.process_batch(label)


def filter_short(label: Sequence[Path], threshold_time: float, output_name: Optional[str] = None) -> List[Path]:
    """Filter short tracks in the given LABEL_DIR(s).

    Args:
        label: Label dir(s) to process.
        threshold_time: Minimum duration of a track (in seconds).
        output_name: Optional individual name for the output directory.

    Returns:
        List of folders with processed data.
    """
    engine = FilterStage(ShortTrackFilter(threshold_time), name=output_name)
    return engine.process_batch(label)


def filter_hampel(
    label: Sequence[Path], time_window: float, n_sigma: float, output_name: Optional[str] = None
) -> List[Path]:
    """Filter tracks with Hampel Outlier filter in the given LABEL_DIR(s).

    Args:
        label: Label dir(s) to process.
        time_window: Window size (in seconds).
        n_sigma: Number of standard deviations.
        output_name: Optional individual name for the output directory.
    """
    engine = FilterStage(HampelOutlierFilter(time_window, n_sigma), name=output_name)
    return engine.process_batch(label)


def filter_savgol(
    label: Sequence[Path], window_length: int, polyorder: int, output_name: Optional[str] = None
) -> List[Path]:
    """Smooth tracks with Savitzky-Golay filter in the given LABEL_DIR(s).

    Args:
        label: label dir(s) to process.
        window_length: Filter window size.
        polyorder: Filter polynomial order.
        output_name: Optional individual

    Returns:
        List of folders with processed data.
    """
    engine = FilterStage(SavGolFilter(window_length=window_length, polyorder=polyorder), name=output_name)
    return engine.process_batch(label)
