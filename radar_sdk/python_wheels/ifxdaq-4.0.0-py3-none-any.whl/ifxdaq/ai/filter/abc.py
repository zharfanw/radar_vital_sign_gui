"""Filter base class."""

from __future__ import annotations

from abc import ABC, abstractmethod
from typing import TYPE_CHECKING, Any, Dict, List

import numpy as np

from ifxdaq.utils.common import fullname

if TYPE_CHECKING:
    import pandas as pd

__all__ = ["get_unique_ids"]


def get_unique_ids(tracks: pd.DataFrame) -> np.ndarray:
    """Extract unique IDs from a set of tracks."""
    return tracks["id"].dropna().unique().astype(int)


class TrackFilterABC(ABC):
    """Abstract base class for tracking filters."""

    def __call__(self, tracks: pd.DataFrame) -> pd.DataFrame:
        """Call `process` method."""
        return self.process(tracks)

    @abstractmethod
    def process(self, tracks: pd.DataFrame) -> pd.DataFrame:
        """Process the tracks with the filter.

        Needs to be implemented by all sub-classes.


        Args:
            tracks: DataFrame containing the tracks.

        Returns:
            Filtered DataFrame.
        """
        raise NotImplementedError

    @property
    def meta_data(self) -> Dict[str, Any]:
        """Filter meta data."""
        return {"filter_name": fullname(self.__class__)}

    @staticmethod
    def _drop_duplicates(dataframe: pd.DataFrame) -> pd.DataFrame:
        """Drop duplicate rows (same index & same values incl. duplicate NaN rows)."""
        _dataframe = dataframe.copy()
        _dataframe["index"] = dataframe.index
        duplicates = _dataframe.astype(str).duplicated()
        return dataframe[~duplicates]

    @staticmethod
    def _drop_nan_duplicates(dataframe: pd.DataFrame) -> pd.DataFrame:
        """Drop duplicated indexed NaN rows that exist already with values, but keep uniquely indexed NaN rows."""
        dataframe = dataframe.copy()
        duplicate_indexes = dataframe.index.duplicated("first") | dataframe.index.duplicated("last")
        duplicate_nan_row = duplicate_indexes & dataframe.isna().all(1)
        return dataframe[~duplicate_nan_row]

    @staticmethod
    def _extract_numeric_columns(dataframe: pd.DataFrame) -> List[str]:
        """Extract numeric columns from the given DataFrame (exclude the `id` column)."""
        columns = dataframe.select_dtypes(include=np.number).columns.tolist()
        try:
            columns.remove("id")
        except ValueError:
            pass
        return columns
