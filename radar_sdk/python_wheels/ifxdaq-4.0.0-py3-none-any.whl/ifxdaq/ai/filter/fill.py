"""Fill gaps in tracks."""

from __future__ import annotations

import numpy as np
import pandas as pd

from ifxdaq.ai.filter.abc import TrackFilterABC, get_unique_ids

__all__ = ["FillGapFilter"]


class FillGapFilter(TrackFilterABC):
    """Fill gaps in tracks.

    Gaps in tracks are filled by linear time interpolation. ``class`` is propagated forward. This filter should be
    applied after merging tracks with with :class:`~ifxdaq.ai.filter.merge.MergeBBoxFilter` to fill the emerging gaps.
    """

    def process(self, tracks: pd.DataFrame) -> pd.DataFrame:
        """Fill gaps in tracks.

        Args:
            tracks: DataFrame containing the tracks.
        """
        tracks = tracks.copy()

        # Keep all empty frames -> Duplicates will be removed later
        filled_tracks = [tracks[tracks.isna().all(1)]]
        for track_id in get_unique_ids(tracks):
            filled_tracks.append(self._fill_gap(tracks[tracks["id"] == track_id], tracks.index))
        filled_tracks = pd.concat(filled_tracks).sort_index()
        filled_tracks = self._drop_duplicates(filled_tracks)
        filled_tracks = self._drop_nan_duplicates(filled_tracks)
        return filled_tracks

    @staticmethod
    def _fill_gap(track: pd.DataFrame, timestamps: pd.DatetimeIndex) -> pd.DataFrame:
        """Fill gaps in track.

        Args:
            track: Single track.
            timestamps: All timestamps.

        Returns:
            Track with filled gaps.
        """
        t_start, t_end = track.index[[0, -1]]
        # Filter out relevant timestamps for track
        timestamps = timestamps[(t_start <= timestamps) & (timestamps <= t_end)]
        missing_timestamps = list(set(timestamps) - set(track.index))
        missing_frame = pd.DataFrame(
            len(missing_timestamps) * [{col: np.NaN for col in track.columns}], index=missing_timestamps
        )
        missing_frame.index.name = track.index.name
        # Fill missing timestamps first with NaNs to create entries
        track = pd.concat([track, missing_frame]).sort_index()
        # Interpolate the missing values
        track["class"] = track["class"].ffill()
        track["id"] = track["id"].ffill()

        numeric_columns = TrackFilterABC._extract_numeric_columns(track)
        track[numeric_columns] = track[numeric_columns].interpolate(method="time", limit_area="inside")

        return track
