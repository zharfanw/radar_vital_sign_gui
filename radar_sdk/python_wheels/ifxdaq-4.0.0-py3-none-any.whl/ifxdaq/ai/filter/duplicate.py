"""Merge/remove duplicated tracks."""

from __future__ import annotations

import itertools
from abc import abstractmethod
from typing import Any, Callable, Dict, Tuple, Union

import numpy as np
import pandas as pd

from ifxdaq.ai.filter.abc import TrackFilterABC, get_unique_ids
from ifxdaq.ai.filter.merge import MergeFilterABC
from ifxdaq.ai.utils import BoundingBox

__all__ = ["DuplicateWorldFilter", "DuplicateBBoxFilter", "DropDuplicateFilter"]


class DuplicateFilter(MergeFilterABC):
    """Identify duplicated tracks and merge them together.

    Compare overlapping areas of tracks. If two tracks are very similar with respect to some metrics, those two tracks
    receive the same track_id.

    Notes:
        We only change the track ids. In consequence you will have multiple detections for one frame which have the
        same track_id. Use the `DropDuplicateFilter` to get rid of those duplicates.

    Args:
        threshold_metric: Threshold for the applied metric between two tracks.
    """

    @property
    def meta_data(self) -> Dict[str, Any]:
        """Filter meta data."""
        meta_data = {
            **super().meta_data,
            **{"parameter": {"threshold_metric": self._threshold_metric}},
        }
        return meta_data

    @staticmethod
    def _calculate_track_costs(tracks: pd.DataFrame, metric: Callable[[pd.Series, pd.Series], float]) -> np.ndarray:
        track_ids = get_unique_ids(tracks)
        costs = np.full(2 * (len(track_ids),), np.NaN)

        for (i, id_x), (j, id_y) in itertools.product(enumerate(track_ids), repeat=2):
            if id_x >= id_y:  # Since metrics are symmetric, only the upper triangular matrix is required
                continue

            track_x = tracks[tracks["id"] == id_x].dropna(axis=0, how="all")
            track_y = tracks[tracks["id"] == id_y].dropna(axis=0, how="all")
            intersection = track_x.index.intersection(track_y.index)
            if len(intersection) == 0:
                continue

            track_x_int = track_x.loc[intersection]
            track_y_int = track_y.loc[intersection]

            if track_x_int["class"].drop_duplicates().equals(track_y_int["class"].drop_duplicates()):
                costs[i, j] = metric(track_x_int, track_y_int)
        return costs

    @abstractmethod
    def _find_most_similar(self, tracks: pd.DataFrame) -> pd.DataFrame:
        raise NotImplementedError


class DuplicateBBoxFilter(DuplicateFilter):
    """Identify duplicated tracks based on the similarity of bounding boxes."""

    @staticmethod
    def _metric(track_x: pd.DataFrame, track_y: pd.DataFrame) -> float:
        track_x = track_x[["bbox_left", "bbox_top", "bbox_right", "bbox_bottom"]]
        track_y = track_y[["bbox_left", "bbox_top", "bbox_right", "bbox_bottom"]]

        bboxes_x = track_x.apply(lambda x: BoundingBox.from_tlbr(np.asarray(x)), axis=1)
        bboxes_y = track_y.apply(lambda x: BoundingBox.from_tlbr(np.asarray(x)), axis=1)

        # Compute iou for all possible pairs
        pairs = bboxes_x.to_frame("bbox_x").join(bboxes_y.to_frame("bbox_y"))
        ious = pairs.apply(lambda x: x["bbox_x"].iou(x["bbox_y"]), axis=1)

        # Only take maximum iou for each frame into account
        ious.sort_values(ascending=False, inplace=True)
        duplicates = ious.index.duplicated(keep="first")
        max_ious_per_frame = ious[~duplicates]

        return float(np.mean(max_ious_per_frame))

    def _find_most_similar(self, tracks: pd.DataFrame) -> Tuple[Union[float, str], Union[float, str]]:
        track_ids = get_unique_ids(tracks)
        similarity = self._calculate_track_costs(tracks, self._metric)
        similarity[similarity < self._threshold_metric] = np.NaN
        if np.isnan(similarity).all():  # No match
            return float("nan"), float("nan")
        similarity = pd.DataFrame(similarity, columns=track_ids, index=track_ids)
        return similarity.max(axis=1).idxmax(), similarity.max(axis=0).idxmax()


class DuplicateWorldFilter(DuplicateFilter):
    """Identify duplicated tracks based on the distance of world coordinates."""

    @staticmethod
    def _metric(track_x: pd.DataFrame, track_y: pd.DataFrame) -> float:
        world_x = track_x[["x", "y", "z"]]
        world_y = track_y[["x", "y", "z"]]

        # Compute distance for all possible pairs
        pairs = world_x.join(world_y, rsuffix="_2")
        distances = pairs.apply(
            lambda row: np.linalg.norm([row["x"] - row["x_2"], row["y"] - row["y_2"], row["z"] - row["z_2"]]), axis=1
        )

        # Only take lowest distance for each frame into account
        distances.sort_values(ascending=True, inplace=True)
        duplicates = distances.index.duplicated(keep="first")
        min_distance_per_frame = distances[~duplicates]

        return float(np.mean(min_distance_per_frame))

    def _find_most_similar(self, tracks: pd.DataFrame) -> Tuple[Union[float, str], Union[float, str]]:
        track_ids = get_unique_ids(tracks)
        distance = self._calculate_track_costs(tracks, self._metric)
        distance[distance > self._threshold_metric] = np.NaN
        if np.isnan(distance).all():  # No match
            return float("nan"), float("nan")
        distance = pd.DataFrame(distance, columns=track_ids, index=track_ids)
        return distance.min(axis=1).idxmin(), distance.min(axis=0).idxmin()


class DropDuplicateFilter(TrackFilterABC):
    """Filter which drops duplicated detections.

    If we have multiple detections of one object for a single frame (i.e. because of merging tracks), this filter only
    keeps the detection with the highest confidence value.
    """

    def process(self, tracks: pd.DataFrame) -> pd.DataFrame:
        """Drop duplicated detections.

        Args:
            tracks: DataFrame containing the tracks.

        Returns:
            Filtered DataFrame.
        """
        tracks = tracks.copy()

        tracks.reset_index(inplace=True)
        tracks.sort_values(by=["timestamp", "confidence"], ascending=[True, False], inplace=True)
        duplicate_free = tracks.drop_duplicates(subset=["timestamp", "id"])
        duplicate_free.set_index("timestamp", inplace=True)

        return duplicate_free
