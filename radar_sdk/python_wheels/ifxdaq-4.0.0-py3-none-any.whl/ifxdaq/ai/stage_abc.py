"""General module for AI based processing steps."""

from __future__ import annotations

import logging
from abc import ABC, abstractmethod
from contextlib import ExitStack
from datetime import datetime
from pathlib import Path
from typing import TYPE_CHECKING, Any, Dict, List, Optional, Sequence

from tqdm import tqdm

from ifxdaq.record import META_DATA_FILE
from ifxdaq.utils.common import fullname, read_json, system_information

if TYPE_CHECKING:
    from ifxdaq.custom_typing import _PathLike

log = logging.getLogger(__name__)

__all__ = ["StageABC"]


class StageABC(ABC):
    """Abstract base class for AI-based processing steps.

    This class provides a general interface for all AI-related processing steps.

    Args:
        name: Name for the destination folder.
    """

    def __init__(self, name: Optional[str] = None) -> None:
        self._context_stack: ExitStack
        self._name = name if name else self.__class__.__name__.replace("Stage", "")

    def process_batch(self, file_list: Sequence[_PathLike]) -> List[Path]:
        """Execute processing steps for a bunch of recordings.

        Args:
            file_list: List of input directories. Depending on the subclass, these may contain actual recordings or
                intermediate processing steps.

        Returns:
            Paths where the results are stored.
        """
        return [
            self.process_single_recording(file_path=file_path)
            for file_path in tqdm(file_list, desc=self._name, unit="Rec", position=0)
        ]

    def process_single_recording(self, file_path: _PathLike) -> Path:
        """Execute the processing steps for a single recording.

        Args:
            file_path: Path to a single directory. Depending on the subclass, these may contain actual recordings or
                intermediate processing steps.

        Returns:
            Directory which contains the results.
        """
        input_dir = Path(file_path).absolute()
        raw_data_dir = self._find_raw_data(input_dir)

        meta_data = self._create_meta_data(input_dir)
        destination_dir = self._get_destination_directory(input_dir.parent, self._name, meta_data)
        if not destination_dir.exists():
            with ExitStack() as self._context_stack:
                self._process_single_recording(input_dir, raw_data_dir, destination_dir, meta_data)

        return destination_dir

    @abstractmethod
    def _process_single_recording(
        self, input_dir: Path, raw_data_dir: Path, destination_dir: Path, meta_data: Dict[str, Any]
    ) -> None:
        """Interface for the concrete stage implementations.

        This method must be overridden.

        Args:
            input_dir: Main input directory for the actual processing step.
            raw_data_dir: Directory which contains the raw camera data.
            destination_dir: Directory where the results are stored.
            meta_data: Dictionary which contains the meta information.
        """
        raise NotImplementedError

    @property
    def stage_settings(self) -> Dict[str, Any]:
        """Provide individual meta-information of the stage.

        Returns:
            Dictionary containing meta-information which are stage specific.
        """
        return {}

    def _create_meta_data(self, input_dir: Path) -> Dict[str, Any]:
        """Collect all relevant meta-information.

        Args:
            input_dir: Path to main inputs of the processing stage.

        Returns:
            Dictionary which contains stage-specific and general meta-information.
        """
        return {
            "name": fullname(self.__class__),
            "input": input_dir.relative_to(input_dir.parents[1]).as_posix(),
            "settings": self.stage_settings,
            "date_created": datetime.now().isoformat(),
            "system_information": system_information(),
        }

    def _find_raw_data(self, input_dir: Path) -> Path:
        """Recursively search for the raw input folder."""
        meta_info = read_json(input_dir / META_DATA_FILE)
        if "input" not in meta_info:
            return input_dir
        return self._find_raw_data(input_dir=input_dir.parents[1] / meta_info["input"])

    def _get_destination_directory(self, root_dir: Path, dir_name: str, meta_data: Dict[str, Any]) -> Path:
        """Get a directory name to store the results.

        Args:
            root_dir: Root directory of the recording to label.
            dir_name: Name of the result directory.
            meta_data: Meta data of the current labeling algorithm.

        Returns:
            Result directory with the smallest running number that is not yet occupied.
        """
        label_dirs = list(root_dir.glob(f"{dir_name}_*"))

        for label_dir in label_dirs:
            if self._check_duplicate_meta_data(meta_data=meta_data, label_dir=label_dir):
                log.warning(
                    "A run with identical settings already exists. Existing files will be used: %s",
                    label_dir.as_posix(),
                )
                return label_dir

        label_num = self._get_smallest_free_number(label_dirs)
        label_dir = root_dir / f"{dir_name}_{label_num:02}"
        return label_dir

    @staticmethod
    def _get_smallest_free_number(label_dirs: Sequence[Path]) -> int:
        """Get the smallest free running number for a directory."""
        used_nums = [int(dir.name[-2:]) for dir in label_dirs]
        label_num = min(set(range(len(used_nums) + 1)) - set(used_nums))
        return label_num

    @staticmethod
    def _check_duplicate_meta_data(meta_data: Dict[str, Any], label_dir: Path) -> bool:
        """Check if the run has the same inputs and settings."""
        stored_meta_data = read_json(label_dir / META_DATA_FILE)
        return meta_data["input"] == stored_meta_data["input"] and meta_data["settings"] == stored_meta_data["settings"]
