"""CLI commands for data labeling."""

from __future__ import annotations

import logging
import os
from logging.handlers import RotatingFileHandler
from pathlib import Path
from typing import Optional, Sequence

import click
import yaml

from ifxdaq import get_cache_dir

log = logging.getLogger(__name__)
PROFILES_DIR = Path(__file__).parent / "profiles"

# pylint: disable=import-outside-toplevel, too-many-locals


@click.command("label")
@click.argument("camera_record", nargs=-1, type=click.Path(exists=True, file_okay=False, path_type=Path), required=True)
@click.option(
    "-c",
    "--config",
    required=False,
    type=click.Path(exists=True, dir_okay=False, path_type=Path),
    help="Path to configuration file, which describes a custom labeling pipeline.",
)
@click.option(
    "-p",
    "--profile",
    required=False,
    type=click.Choice([cfg_file.stem for cfg_file in PROFILES_DIR.iterdir() if cfg_file.suffix == ".yaml"]),
    help="Select a pre-defined labeling pipeline.",
)
def cmd_label(camera_record: Sequence[Path], config: Optional[Path], profile: Optional[str]) -> None:
    """Label the given CAMERA_RECORD(s).

    Execute a multi-stage labeling pipeline to generate labels from the given CAMERA_RECORD(s). Select from a set of
    pre-defined labeling pipelines (`-p / --profile`) or pass a custom configuration file (`-c / --config`).
    """
    try:
        from ifxdaq.ai.compose.stage import compose
        from ifxdaq.ai.filter.stage import filter_hampel, filter_savgol, filter_short, merge_tracks
        from ifxdaq.ai.visualization.stage import visualization
        from ifxdaq.ai.world_coordinates.stage import world_coordinates
        from ifxdaq.ai.yolo.stage import yolo
    except ModuleNotFoundError:
        log.error("Please install the `ai` extension to use labeling algorithms.")
        return

    # Labeling does not need any QT GUI features, so we can completely disable it to prevent any issues on
    # headless-servers.
    os.environ["QT_QPA_PLATFORM"] = "offscreen"

    stages = [
        compose,
        yolo,
        visualization,
        world_coordinates,
        merge_tracks,
        filter_short,
        filter_hampel,
        filter_savgol,
    ]
    stage_mapping = {func.__name__: func for func in stages}

    if config is None:
        if profile is None:
            log.error("No config file was passed. Either pass a config file (-c) or use a pre-defined profile (-p).")
            return
        config = PROFILES_DIR / f"{profile}.yaml"

    log_dir = get_cache_dir() / "logs"
    log_dir.mkdir(exist_ok=True, parents=True)

    formatter = logging.Formatter(
        "[%(asctime)s.%(msecs)03d PID:%(process)5d TID:%(thread)5d %(levelname)s %(name)s]: %(message)s",
        datefmt="%H:%M:%S",
    )
    _log = logging.getLogger("ifxdaq")
    _log.setLevel(logging.DEBUG)

    file_handler = RotatingFileHandler(log_dir / "label.log", "w", 2**20, 5, "utf-8", delay=False)
    file_handler.setFormatter(formatter)
    file_handler.setLevel(logging.DEBUG)
    _log.addHandler(file_handler)

    with open(config, "r", encoding="utf-8") as file:
        pipeline = yaml.safe_load(file)
    for pipeline_stage in pipeline:
        for stage, settings in pipeline_stage.items():
            camera_record = stage_mapping[stage](camera_record, **settings if settings else {})  # type: ignore

    for handler in _log.handlers:
        _log.removeHandler(handler)
        handler.close()
