"""This package contains the base functionality and the implementations of the different sensor types."""
