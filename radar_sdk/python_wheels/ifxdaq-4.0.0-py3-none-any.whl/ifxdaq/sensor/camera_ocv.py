"""This module contains the implementation to access webcams via OpenCV.

Warnings:
    Using `CamOpenCV` has side effects on other camera devices like
    :class:`~ifxdaq.sensor.camera_irs.CamIntelRealSense`. It is recommended
    to use this class only very cautious and with no other camera classes.

See Also:
    - :ref:`rgb`: Data file format.
    - `OpenCV`_
    - `OpenCV Docs`_

Examples:
    Import:

    >>> from ifxdaq.sensor.camera_ocv import CamOpenCV

    Discover devices:

    >>> CamOpenCV.discover() # doctest: +ELLIPSIS
    [...]

    Open camera with default configuration (A config file, which can be
    modified is created):

    >>> config_file = CamOpenCV.create_default_config_file()
    >>> with CamOpenCV(config_file) as cam:
    ...     for frame in cam:
    ...         print(frame)
    [...]

.. _OpenCV:
    https://opencv.org
.. _OpenCV Docs:
    https://docs.opencv.org/
"""

from __future__ import annotations

import json
import logging
import time
from typing import TYPE_CHECKING, Any, Dict, List, Optional

import cv2
import numpy as np

from ifxdaq.errors import SensorConfigurationError, SensorError, SensorNotFoundError
from ifxdaq.sensor.abc import Frame, FrameFormat, SensorABC
from ifxdaq.utils.common import read_json

if TYPE_CHECKING:
    from ifxdaq.custom_typing import _PathLike

log = logging.getLogger(__name__)

__all__ = ["CamOpenCV"]


class CamOpenCV(SensorABC):
    """Wrapper class for Webcams built-on OpenCV.

    Args:
        config_file: Path to configuration file to use the camera. (.json)
        device_id: If given, the sensor which matches the ID will be accessed.
            Otherwise, a random connected device will be accessed.

    Important:
        This device returns a ``Dict`` that contains a :class:`~ifxdaq.sensor.abc.Frame` for those sensors:

            - ``rgb``: Image (RGB) data.

        Be aware, that frames can contain only a subset of data for the above mentioned sensor types, because the
        sensors are not physically aligned and return asynchronously data. If a sensor has no new data, ``None`` will be
        returned instead. Ensure in your code that you implement corresponding checks.
    """

    MAX_DEVICE_ID = 1  # Use only builtin camera - other cause side effects with proprietary drivers
    config_file_suffix = ".json"

    def __init__(self, config_file: _PathLike, device_id: Optional[str] = None) -> None:
        self._device: cv2.VideoCapture
        super().__init__(config_file, device_id)

    def _get_frame_format(self) -> Dict[str, FrameFormat]:
        """Extract the frame format for the camera stream from a configuration file.

        Args:
            config_file: Path to the config file to extract the frame format.

        Raises:
            SensorConfigurationError: If an invalid `config_file` was passed.

        Returns:
            The frame format with attributes like `shape`, `dtype` & `fps`.
        """
        config = read_json(self.config_file)

        try:
            frame_format = {
                "rgb": FrameFormat(
                    dtype=np.dtype("uint8"),
                    fps=config["CAP_PROP_FPS"],
                    shape=(config["CAP_PROP_FRAME_HEIGHT"], config["CAP_PROP_FRAME_WIDTH"], 3),
                )
            }
        except KeyError as excp:
            raise SensorConfigurationError("Invalid configuration file.") from excp

        return frame_format

    @classmethod
    def discover(cls) -> List[str]:
        """Discover connected Webcam devices.

        Exemplary device identifier: `0`

        Returns:
            List of device identifiers for all connected devices.
        """
        log.debug("%s | Looking for devices...", cls.__name__)
        # OpenCV has no capabilities to list all detected devices.
        # Hence, we iterate over a reasonable range and check
        # if this index represents an accessible device
        # https://stackoverflow.com/questions/8044539
        device_list = []
        for device_id in range(CamOpenCV.MAX_DEVICE_ID):
            cap = cv2.VideoCapture(device_id, cv2.CAP_ANY)
            if cap and cap.isOpened():
                success, _ = cap.read()
                if success:
                    log.info("%s | Found device with ID %s.", cls.__name__, device_id)
                    device_list.append(str(device_id))
                    cap.release()
        return device_list

    def _open_device(self) -> None:
        try:
            self._device = cv2.VideoCapture(int(self.device_id), cv2.CAP_ANY)
        except ValueError as excp:
            raise SensorNotFoundError("Invalid device id.") from excp
        if not self._device.isOpened():
            raise SensorError("Failed to open WebCam.")

    def _set_config(self, config: Dict[str, Any]) -> None:
        log.warning(
            "Even if no error is raised this does not ensure that the "
            "configuration has been accepted by the capture device. "
            "Find more information in the OpenCV docs."
        )
        for prop, value in config.items():
            if hasattr(cv2, prop):
                prop_id = getattr(cv2, prop)
                status = self._device.set(prop_id, value)
                if not status:
                    log.warning(
                        "%s: %s | Device does not support configuration parameter %s",
                        type(self).__name__,
                        self._device_id,
                        prop,
                    )
            else:
                raise SensorConfigurationError(f"Configuration parameter {prop} is not valid.")

    def _configure_device(self) -> None:
        try:
            config = read_json(self._config_file)
        except json.decoder.JSONDecodeError as excp:
            raise SensorConfigurationError("No valid JSON configuration.") from excp
        log.debug("%s: %s | Loaded configuration file.", type(self).__name__, self._device_id)

        self._set_config(config)

    def _start_device(self) -> None:
        # Intentionally left blank -> There is nothing to do
        pass

    def _close_device(self) -> None:
        self._device.release()
        del self._device

    def _generate_meta_data(self) -> Dict[str, str]:
        meta_data = {"device_id": self.device_id, "backend": self._device.getBackendName()}
        return meta_data

    def _get_data_from_device(self) -> Dict[str, Optional[Frame]]:
        # Grab image from device -> Fast access, decode afterwards
        status_grab = self._device.grab()
        timestamp = time.time()
        # Decode now the image
        status_retrieve, data = self._device.retrieve()
        if not status_grab or not status_retrieve:
            raise SensorError(
                f"Failed to read image. Grab Status: {status_grab} " f"Retrieve Status: {status_retrieve}"
            )
        data = cv2.cvtColor(data, cv2.COLOR_BGR2RGB)
        return {"rgb": Frame(timestamp=timestamp, data=data)}
