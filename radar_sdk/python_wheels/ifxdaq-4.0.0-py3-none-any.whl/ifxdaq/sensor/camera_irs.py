"""This module contains the implementation to access Intel RealSense cameras.

Note:
    This module supports `Intel® RealSense™`_ depth cameras (D400 series and
    the SR300). A configuration can be created with the RealSense viewer.
    More keys have to be added to the configuration file, because the
    viewer doesn't export them:

    - ``stream-rgb-format``: RGB data format (default: ``RGB8``).
    - ``stream-rgb-fps``: RGB frames per second.
    - ``stream-rgb-height``: Height of the color stream.
    - ``stream-rgb-width``: Width of the color stream.
    - ``enable-rgb``: Enable RGB.
    - ``enable-depth``: Enable depth.
    - ``enable-ir``: Enable (both) infrared images.

See Also:
    - :ref:`rgb`: Data file format.
    - :ref:`depth`: Data file format.
    - `Intel® RealSense™ Depth Camera Get started Guide`_

Examples:
    Import:

    >>> from ifxdaq.sensor.camera_irs import CamIntelRealSense

    Discover devices:

    >>> CamIntelRealSense.discover() # doctest: +ELLIPSIS
    [...]

    Open camera with default configuration (A config file, which can be modified is created;
    Default data streams: rgb & depth):

    >>> config_file = CamIntelRealSense.create_default_config_file()
    >>> with CamIntelRealSense(config_file) as cam:
    ...     for frame in cam:
    ...         print(frame)
    [...]

.. _Intel® RealSense™:
    https://www.intelrealsense.com/
.. _Building From Source:
    https://github.com/IntelRealSense/librealsense/tree/master/wrappers/python#building-from-source
.. _Intel® RealSense™ Depth Camera Get started Guide:
    https://www.intelrealsense.com/get-started-depth-camera/
"""

from __future__ import annotations

import logging
from dataclasses import dataclass
from typing import TYPE_CHECKING, Any, Dict, List, Optional, Tuple

import numpy as np
from packaging import version

from ifxdaq.errors import SensorConfigurationError, SensorError, SensorNotFoundError
from ifxdaq.sensor.abc import Frame, FrameFormat, SensorABC
from ifxdaq.utils.common import read_json, str2bool

if TYPE_CHECKING:
    from ifxdaq.custom_typing import _PathLike

try:
    import pyrealsense2.pyrealsense2 as rs
except ModuleNotFoundError as import_excp:
    raise ImportError(
        "Failed to import driver for Intel RealSense cameras. "
        "Install pyrealsense2 package from https://github.com/IntelRealSense/librealsense."
    ) from import_excp


log = logging.getLogger(__name__)

__all__ = ["CamIntelRealSense", "intrinsics_to_dict", "intrinsics_from_dict"]


class CamIntelRealSense(SensorABC):  # pylint: disable=too-many-instance-attributes
    """Wrapper class for Intel® RealSense™ cameras.

    Args:
        config_file: Path to configuration file to use the camera. (.json)
        device_id: If given, the sensor which matches the ID will be accessed.
            Otherwise, a random connected device will be accessed.

    Important:
        This device returns a ``Dict`` that contains a :class:`~ifxdaq.sensor.abc.Frame` for those sensors:

            - ``rgb``: Image (RGB) data.
            - ``depth``: Depth image.
            - ``ir1``: Infrared image 1.
            - ``ir2``: Infrared image 2.

        Be aware, that frames can contain only a subset of data for the above mentioned sensor types, because the
        sensors are not physically aligned and return asynchronously data. If a sensor has no new data, ``None`` will be
        returned instead. Ensure in your code that you implement corresponding checks.
    """

    TIMEOUT_MS = 1000
    config_file_suffix = ".json"

    def __init__(self, config_file: _PathLike, device_id: Optional[str] = None) -> None:
        self._enable_rgb: bool
        self._enable_depth: bool
        self._enable_ir: bool

        self._config: "rs.config"
        self._pipeline: "rs.pipeline"
        self._device: "rs.device"
        self._align: Optional["rs.align"] = None
        self._hole_filling_filter: Optional["rs.hole_filling_filter"] = None
        self._frame_numbers: Dict[str, int] = {}

        super().__init__(config_file, device_id)

    @classmethod
    def discover(cls) -> List[str]:
        """Discover connected Realsense devices.

        Exemplary device identifier: `035722250135`

        Returns:
            List of device identifiers for all connected devices.
        """
        log.debug("%s | Looking for devices...", cls.__name__)
        discovered_devices = []

        for device in rs.context().devices:
            serial = device.get_info(rs.camera_info.serial_number)
            log.info("%s | Found device with serial %s.", cls.__name__, serial)
            discovered_devices.append(serial)

        return discovered_devices

    def _get_frame_format(self) -> Dict[str, FrameFormat]:
        """Extract the frame format for all camera streams from a configuration file.

        Args:
            config_file: Path to the config file to extract the frame format.

        Raises:
            SensorConfigurationError: If an invalid `config_file` was passed.

        Returns:
            The frame format with attributes like `shape`, `dtype` & `fps`.
        """
        config = read_json(self._config_file)
        try:
            frame_config = config["viewer"]
            frame_format = {}
            if str2bool(frame_config["enable-rgb"]):
                rgb_fps = int(frame_config["stream-rgb-fps"])
                rgb_h = int(frame_config["stream-rgb-height"])
                rgb_w = int(frame_config["stream-rgb-width"])
                frame_format["rgb"] = FrameFormat(np.dtype("uint8"), rgb_fps, (rgb_h, rgb_w, 3))
            if str2bool(frame_config["enable-depth"]) or str2bool(frame_config["enable-ir"]):
                d_fps = int(frame_config["stream-fps"])
                d_h = int(frame_config["stream-height"])
                d_w = int(frame_config["stream-width"])
                if str2bool(frame_config["enable-depth"]):
                    frame_format["depth"] = FrameFormat(np.dtype("uint16"), d_fps, (d_h, d_w))
                if str2bool(frame_config["enable-ir"]):
                    frame_format["ir1"] = FrameFormat(np.dtype("uint8"), d_fps, (d_h, d_w))
                    frame_format["ir2"] = FrameFormat(np.dtype("uint8"), d_fps, (d_h, d_w))
        except KeyError as excp:
            raise SensorConfigurationError("Invalid configuration file.") from excp

        return frame_format

    def _open_device(self) -> None:
        self._device = self._get_device(self.device_id)
        usb_type = self._device.get_info(rs.camera_info.usb_type_descriptor)
        if version.parse(usb_type) < version.parse("3.1"):
            raise SensorError("Intel RealSense requires at least USB3.1 and compatible cables.")
        fw_version = self._device.get_info(rs.camera_info.firmware_version)
        if version.parse(fw_version) < version.parse("05.13.00.50"):
            raise SensorError(
                "Intel RealSense requires at least firmware v05.13.00.50. "
                "Use the Intel RealSense Viewer to flash the latest firmware."
            )

        self._pipeline = rs.pipeline()

    def _configure_device(self) -> None:
        log.debug("%s: %s | Loaded configuration file.", type(self).__name__, self._device_id)
        self._enable_rgb = "rgb" in self.frame_format
        self._enable_depth = "depth" in self.frame_format
        self._enable_ir = "ir2" in self.frame_format

        self._config = rs.config()
        self._config.enable_device(self.device_id)
        self._enable_streams()
        try:
            self._pipeline.start(self._config)
        except RuntimeError as excp:
            raise SensorConfigurationError("Invalid configuration.") from excp
        log.debug("%s: %s | Configured streams.", type(self).__name__, self._device_id)

        if self._enable_rgb and self._enable_depth:
            self._align = rs.align(rs.stream.color)  # Align all frames w.r.t. the color frames.
            # Lower the priority of the auto exposure -> This enables more stable frame rates
            # and hardware sync between the RGB & depth module.
            self._device.first_color_sensor().set_option(rs.option.auto_exposure_priority, 0.0)
        if self._enable_depth:
            self._hole_filling_filter = rs.hole_filling_filter(2)

        configuration = self.remove_custom_keys(read_json(self._config_file))
        advanced_mode = rs.rs400_advanced_mode(self._device)
        try:
            advanced_mode.load_json(str(configuration).replace("'", '"'))
        except RuntimeError as excp:
            raise SensorConfigurationError("Invalid configuration.") from excp
        log.debug("%s: %s | Loaded advanced configuration parameters.", type(self).__name__, self._device_id)

    def _start_device(self) -> None:
        pass

    def _generate_meta_data(self) -> Dict[str, Any]:
        meta_data = {
            "device_type": self._device.get_info(rs.camera_info.name),
            "serial": self.device_id,
            "pyrealsense_version": rs.__version__,
            "firmware": self._device.get_info(rs.camera_info.firmware_version),
            "usb_type": self._device.get_info(rs.camera_info.usb_type_descriptor),
        }

        profile = self._pipeline.get_active_profile()
        if self._enable_rgb:
            intrinsics = profile.get_stream(rs.stream.color).as_video_stream_profile().get_intrinsics()
            meta_data["color_intrinsics"] = intrinsics_to_dict(intrinsics)
            meta_data["color_fov"] = rs.rs2_fov(intrinsics)
        if self._enable_depth:
            intrinsics = profile.get_stream(rs.stream.depth).as_video_stream_profile().get_intrinsics()
            meta_data["depth_intrinsics"] = intrinsics_to_dict(intrinsics)
            meta_data["depth_scale"] = self._device.first_depth_sensor().get_depth_scale()
            meta_data["depth_fov"] = rs.rs2_fov(intrinsics)
        return meta_data

    def _get_data_from_device(self) -> Dict[str, Optional[Frame]]:
        try:
            raw_frame = self._pipeline.wait_for_frames(timeout_ms=CamIntelRealSense.TIMEOUT_MS)
        except RuntimeError as excp:
            raise TimeoutError("Failed to get frame from camera.") from excp

        if self._align is not None:
            raw_frame = self._align.process(raw_frame)

        frame = {}
        if self._enable_rgb:
            frame.update(self._extract_data_from_frame(raw_frame.get_color_frame(), "rgb"))
        if self._enable_depth:
            depth_frame = raw_frame.get_depth_frame()
            if self._hole_filling_filter is not None:
                depth_frame = self._hole_filling_filter.process(depth_frame)
            frame.update(self._extract_data_from_frame(depth_frame, "depth"))
        if self._enable_ir:
            frame.update(self._extract_data_from_frame(raw_frame.get_infrared_frame(1), "ir1"))
            frame.update(self._extract_data_from_frame(raw_frame.get_infrared_frame(2), "ir2"))
        return frame

    def _extract_data_from_frame(self, frame: "rs.frame", name: str) -> Dict[str, Optional[Frame]]:
        data: Dict[str, Optional[Frame]] = {name: None}
        try:
            new_frame_arrived = self._frame_numbers[name] < frame.frame_number
        except KeyError:  # First frame
            self._frame_numbers[name] = frame.frame_number
            new_frame_arrived = True
        if new_frame_arrived:
            missed_frames = frame.frame_number - (self._frame_numbers[name] + 1)
            if missed_frames > 0:
                log.debug(
                    "%s: %s | %s: Dropped %s frame%s.",
                    type(self).__name__,
                    self._device_id,
                    name,
                    missed_frames,
                    "s" if missed_frames > 1 else "",
                )
            self._frame_numbers[name] = frame.frame_number
            # Warning!
            # The RealSense camera uses always the same memory to store data. `np.asarray` casts this memory area into
            # a numpy array, but the data is still at the same place. If the camera acquires now a new frame, the new
            # data overwrites the old data. Since the numpy area holds a pointer to this area, also the content of the
            # numpy array is changed. This can lead to duplicated frames for high frame rates.
            #
            # This could be avoided by creating a copy of every frame; however the data of the RealSense is quite big
            # and allocating + copying so much data is too expensive.
            data[name] = Frame(timestamp=frame.timestamp / 1000.0, data=np.asarray(frame.data))
        return data

    def _close_device(self) -> None:
        self._pipeline.stop()

    def _enable_streams(self) -> None:
        stream_parameters: Dict[str, Any] = {}

        for stream, fformat in self.frame_format.items():
            params: Tuple[Any, ...]
            if stream == "rgb":
                params = (rs.stream.color, fformat.shape[1], fformat.shape[0], rs.format.rgb8, int(fformat.fps))
            elif stream == "depth":
                params = (rs.stream.depth, fformat.shape[1], fformat.shape[0], rs.format.z16, int(fformat.fps))
            elif stream == "ir1":
                params = (rs.stream.infrared, 1, fformat.shape[1], fformat.shape[0], rs.format.y8, int(fformat.fps))
            elif stream == "ir2":
                params = (rs.stream.infrared, 2, fformat.shape[1], fformat.shape[0], rs.format.y8, int(fformat.fps))
            else:
                raise SensorConfigurationError(f"Unknown data stream {stream}.")

            stream_parameters[stream] = params

        for stream_name, params in stream_parameters.items():
            self._config.enable_stream(*params)
            if not self._config.can_resolve(self._pipeline):
                raise SensorConfigurationError(
                    f"Invalid configuration for {stream_name} stream. "
                    f"Valid configurations are: \n\t{self._get_available_lists_string()}"
                )

    def _get_available_lists_string(self) -> str:
        valid_streams = self.get_valid_streams(self.device_id)
        return "\n\t".join([str(s) for s in valid_streams if s.name in ["Color", "Depth"]])

    @classmethod
    def _get_device(cls, serial: str) -> "rs.device":
        discovered_devices = {device.get_info(rs.camera_info.serial_number): device for device in rs.context().devices}
        if serial in discovered_devices:
            device = discovered_devices[serial]
            log.debug("%s | Got device handle for camera device with serial %s.", cls.__name__, serial)
        else:
            raise SensorNotFoundError(f"Found no camera device with serial {serial}.")

        return device

    @classmethod
    def get_valid_streams(cls, device_id: str) -> List["StreamParameters"]:
        """Get the list of valid stream configurations for a connected device.

        Args:
            device_id: Serial number of a connected device, like `035722250135`.

        Returns:
            List of valid stream configurations.
        """
        device = cls._get_device(device_id)

        streams = [
            device.first_color_sensor,
            device.first_depth_sensor,
            device.first_motion_sensor,
            device.first_fisheye_sensor,
            device.first_pose_sensor,
        ]

        valid_streams = []
        for stream_getter in streams:
            try:
                stream = stream_getter()
            except RuntimeError:
                pass
            else:
                for profile in stream.get_stream_profiles():
                    profile = profile.as_video_stream_profile()
                    profile = StreamParameters(
                        profile.stream_name(),
                        profile.stream_type(),
                        profile.width(),
                        profile.height(),
                        profile.fps(),
                        profile.format(),
                    )
                    valid_streams.append(profile)

        return valid_streams

    @staticmethod
    def remove_custom_keys(configuration: Dict[str, Dict[str, str]]) -> Dict[str, Dict[str, str]]:
        """Remove the custom keys that are introduced to control frame rate & resolution of individual streams."""
        custom_keys = [
            "stream-ir-format",
            "stream-rgb-format",
            "stream-rgb-fps",
            "stream-rgb-height",
            "stream-rgb-width",
            "enable-rgb",
            "enable-depth",
            "enable-ir",
        ]
        configuration = configuration.copy()
        for key in custom_keys:
            configuration["viewer"].pop(key, None)
        return configuration


@dataclass
class StreamParameters:
    """Dataclass to store stream parameters."""

    name: str
    """The name of the stream, e.g. `Color`."""
    stream: "rs.stream"
    # """The class of the stream, e.g. ``rs.stream.color``."""
    width: int
    """The width of a frame."""
    height: int
    """The height of a frame."""
    fps: int
    """The frame rate."""
    format: "rs.format"
    """The format class, e.g. ``rs.format.rgb8``."""

    def __str__(self) -> str:
        return f"{self.name} ({self.stream}): {self.width}x{self.height} @ {self.fps} fps as {self.format}"


def intrinsics_to_dict(intrinsics: "rs.intrinsics") -> Dict[str, Any]:
    """Convert intrinsics into a json-serializable dictonary.

    Args:
        intrinsics: Intrinsics.

    Returns:
        Dictionary with intrinsics.
    """
    return {
        "coeffs": intrinsics.coeffs,
        "fx": intrinsics.fx,
        "fy": intrinsics.fy,
        "ppx": intrinsics.ppx,
        "ppy": intrinsics.ppy,
        "model": intrinsics.model.value,
        "height": intrinsics.height,
        "width": intrinsics.width,
    }


def intrinsics_from_dict(intrinsics_dict: Dict[str, Any]) -> "rs.intrinsics":
    """Build intrinsics from a dictionary.

    Args:
        intrinsics_dict: Dictionary with intrinsics.

    Returns:
        Intrinsics.
    """
    intrinsics = rs.intrinsics()
    for name, value in intrinsics_dict.items():
        if name == "model":
            intrinsics.model = rs.distortion(value)
        else:
            setattr(intrinsics, name, value)
    return intrinsics
