"""This module contains frame definitions and the abstract class used as a boilerplate for all sensors."""

from __future__ import annotations

import logging
import shutil
from abc import ABC, abstractmethod
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path
from typing import TYPE_CHECKING, Any, Dict, List, Optional, Sequence, Tuple, Type, Union

import numpy as np

from ifxdaq.errors import SensorNotFoundError
from ifxdaq.utils.common import verify_file

if TYPE_CHECKING:
    from types import TracebackType

    from ifxdaq.custom_typing import _PathLike

log = logging.getLogger(__name__)

__all__: List[str] = ["Frame", "FrameFormat"]


@dataclass
class FrameFormat:
    """Data class containing the format of sensor frames."""

    dtype: np.dtype
    """The data type of a frame."""
    fps: float
    """The frame rate of the frames."""
    shape: Tuple[int, ...]
    """The shape of a frame."""

    def __init__(self, dtype: Union[str, np.dtype], fps: Union[int, float], shape: Sequence[int]) -> None:
        self.dtype = np.dtype(dtype)
        self.fps = float(fps)
        self.shape = tuple(shape)

    def __repr__(self) -> str:
        return f"{self.shape} | {self.dtype} @ {self.fps:.2f} fps"


@dataclass
class Frame:
    """Data class containing a frame from a single sensor."""

    timestamp: float
    """Timestamp of the frame."""
    data: Any
    """Data of the frame."""

    def __repr__(self) -> str:
        return f"{datetime.fromtimestamp(self.timestamp).isoformat()} | shape: {np.shape(self.data)}"


class SensorABC(ABC):
    """Abstract base class for different types of sensors.

    This class should be used as a boilerplate for different sensors. Please follow the API of the abstract methods
    to create compliant sensor classes.

    Args:
        config_file: Path to configuration file to use a sensor in live mode.
        device_id: Specifies the sensor to use. If None, the first detected device will be accessed.
        **kwargs: Keyword arguments to allow extension in sub-classes, while keeping the Liskov Substitution Principle.
    """

    config_file_suffix: str

    def __init__(self, config_file: _PathLike, device_id: Optional[str] = None) -> None:
        self._buf: Dict[str, np.ndarray] = {}
        self._frame_format: Dict[str, FrameFormat]
        self._device_id = device_id
        super().__init__()
        self._config_file = Path(config_file)
        verify_file(self._config_file)

        self._check_device_id()
        log.debug("%s: %s | Setting up device.", type(self).__name__, self._device_id)
        self._open_device()
        log.debug("%s: %s | Opened device.", type(self).__name__, self._device_id)
        self._configure_device()
        log.debug("%s: %s | Configured device using %s.", type(self).__name__, self._device_id, self._config_file)
        self._start_device()
        log.info("%s: %s | Started device.", type(self).__name__, self._device_id)
        self._meta_data = self._generate_meta_data()
        log.debug("%s: %s | Generated meta data.", type(self).__name__, self._device_id)

    @property
    def device_id(self) -> str:
        """The sensor's identifier."""
        return str(self._device_id)

    @property
    def config_file(self) -> Path:
        """Configuration file of the sensor."""
        return self._config_file

    @property
    def meta_data(self) -> Dict[str, Any]:
        """The device's meta data (e.g. driver version)."""
        return self._meta_data

    @property
    def data(self) -> Dict[str, Optional[Frame]]:
        """Current data frame incl. timestamp."""
        data = self._get_data_from_device()
        return data

    @property
    def frame_format(self) -> Dict[str, FrameFormat]:
        """The sensor's frame format."""
        if not hasattr(self, "_frame_format"):
            self._frame_format = self._get_frame_format()
            log.debug("%s: %s | Derive frame format.", type(self).__name__, self._device_id)
        return self._frame_format

    @classmethod
    def create_default_config_file(cls, dst: _PathLike = ".", name: Optional[str] = None) -> Path:
        """Create a default configuration file for the sensor.

        Args:
            dst: Destination directory of the created configuration.
            name : Used as file stem (`string.suffix`). If not specified the
                sensor class name is used as stem (`sensor_class.suffix`).

        Raises:
            ValueError: If default configuration file could not be found.

        Returns:
            Path of the created configuration file.
        """
        default_configs = Path(__file__).parent / "default_configs"

        src_file = default_configs / f"{cls.__name__}{cls.config_file_suffix}"
        if not src_file.exists():
            raise ValueError(
                f"There must be exactly one default configuration file for each sensor in {default_configs}."
            )

        dst = Path(dst).resolve()
        dst.mkdir(exist_ok=True, parents=True)
        dst = dst / f"{name if name else cls.__name__}{cls.config_file_suffix}"

        if not dst.exists():
            shutil.copyfile(src_file, dst)
            log.debug("Created default configuration file. %s", dst.as_posix())
        else:
            log.warning("File already exists. Returning existing file. %s", dst.as_posix())

        return dst

    @classmethod
    @abstractmethod
    def discover(cls) -> List[str]:
        """Discover connected devices.

        Returns:
            List of device identifiers for all connected devices.
        """
        raise NotImplementedError

    def close(self) -> None:
        """Close the connected sensor."""
        self._close_device()
        log.info("%s: %s | Closed device.", type(self).__name__, self._device_id)

    def _check_device_id(self) -> None:
        """Check and set the device identifier.

        If no device identifier is provided, connected devices are discovered and a random device is used.

        Raises:
            SensorNotFoundError: If no device identifier is provided and no connected devices are discovered.
        """
        if self._device_id is None:
            log.debug("%s | No device id provided. Looking for devices.", type(self).__name__)
            discovered_devices = self.discover()
            if not discovered_devices:
                raise SensorNotFoundError("No device id provided and no connected devices found.")
            self._device_id = discovered_devices.pop()

    @abstractmethod
    def _open_device(self) -> None:
        """Open a connected sensor.

        Raises:
            SensorError: If opening the device failed.
        """
        raise NotImplementedError

    @abstractmethod
    def _configure_device(self) -> None:
        """Configure a sensor from a configuration file.

        Raises:
            SensorConfigurationError: If configuring the device failed.
        """
        raise NotImplementedError

    @abstractmethod
    def _start_device(self) -> None:
        """Start a connected sensor.

        Raises:
            SensorError: If starting the device failed.
        """
        raise NotImplementedError

    @abstractmethod
    def _get_frame_format(self) -> Dict[str, FrameFormat]:
        """Derive the frame format (dtype, shape, fps) from a configuration file or from the sensor.

        Returns:
            The frame format for all (sub-)sensor(s) with attributes like `shape`, `dtype` & `fps`.
        """
        raise NotImplementedError

    @abstractmethod
    def _generate_meta_data(self) -> Dict[str, Any]:
        """Generate device dependent meta data, e.g. device id, firmware version, etc.

        Returns:
            Meta data.
        """
        raise NotImplementedError

    @abstractmethod
    def _get_data_from_device(self) -> Dict[str, Optional[Frame]]:
        """Get data from a connected sensor.

        Returns:
            Tuple containing the Unix timestamp in seconds and a data frame
            of the (virtual) sensor. A frame can contain multiple data streams.

        Raises:
            TimeoutError: If no data arrived within a defined period of time.
        """
        raise NotImplementedError

    @abstractmethod
    def _close_device(self) -> None:
        """Close a connected sensor.

        Raises:
            SensorError: If closing the device failed.
        """
        raise NotImplementedError

    def __enter__(self: "SensorABC") -> "SensorABC":
        log.debug("%s: %s | Entered context manager.", type(self).__name__, self._device_id)
        return self

    def __exit__(
        self,
        exc_type: Optional[Type[BaseException]],
        exc_value: Optional[BaseException],
        traceback: Optional[TracebackType],
    ) -> None:
        self.close()
        log.debug("%s: %s | Exited context manager.", type(self).__name__, self._device_id)

    def __iter__(self: "SensorABC") -> "SensorABC":
        return self

    def __next__(self) -> Dict[str, Optional[Frame]]:
        return self.data
