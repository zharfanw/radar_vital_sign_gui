"""This module contains the implementation to access Infineon 60 GHz radars.

Warnings:
    We require firmware version >= 2.6.0. Available in the  `Infineon Toolbox`_.

Note:
    To enable the MIMO mode, set `mimo_mode` in the radar configuration file to `tdm`.

See Also:
    - :ref:`radar`: Radar data file format.
    - :ref:`temperature`: Temperature data file format.
    - `RDK`_: Underlying driver library.

Examples:
    Import:

    >>> from ifxdaq.sensor.radar_ifx import RadarIfxAvian

    Discover devices:

    >>> RadarIfxAvian.discover() # doctest: +ELLIPSIS
    [...]

    Open radar with default configuration (A config file, which can be modified is created):

    >>> config_file = RadarIfxAvian.create_default_config_file()
    >>> with RadarIfxAvian(config_file) as radar:
    ...     for frame in radar:
    ...         print(frame)
    [...]

.. _Infineon Toolbox:
    https://confluencewikiprod.intra.infineon.com/display/DP/Infineon+Toolbox+Home
.. _RDK:
    https://bitbucket.vih.infineon.com/projects/MMWSW/repos/rdk/browse
"""

from __future__ import annotations

import json
import logging
import tempfile
import time
from enum import Enum
from typing import TYPE_CHECKING, Dict, List, Optional, Union, cast, no_type_check

import numpy as np
from ifxradarsdk import get_version_full
from ifxradarsdk.common.common_types import RadarSensor
from ifxradarsdk.common.exceptions import ErrorDevBase, ErrorNoDevice, ErrorTimeout
from ifxradarsdk.fmcw import DeviceFmcw
from ifxradarsdk.fmcw.types import (
    FmcwSequenceChirp,
    FmcwSequenceLoop,
    FmcwSimpleSequenceConfig,
)

from ifxdaq.errors import SensorConfigurationError, SensorError, SensorNotFoundError
from ifxdaq.sensor.abc import Frame, FrameFormat, SensorABC
from ifxdaq.utils.common import read_json

if TYPE_CHECKING:
    from ifxdaq.custom_typing import _PathLike

log = logging.getLogger(__name__)

__all__ = ["RadarIfxAvian", "antenna_list_to_mask", "antenna_mask_to_list"]


class SupportedSchemas(Enum):
    """Supported configuration file schemas.

    Find more details in the RDK documentation under "JSON Configuration".
    """

    FMCW_SINGLE_SHAPE = "fmcw_single_shape"


class RadarIfxAvian(SensorABC):
    """Wrapper class for Infineon 60 GHz radar devices.

    Args:
        config_file: Path to configuration file to use the camera. (.json)
        device_id: If given, the sensor which matches the ID will be accessed.
            Otherwise, a random connected device will be accessed.

    Important:
        This device returns a ``Dict`` that contains a :class:`~ifxdaq.sensor.abc.Frame` for those sensors:

            - ``radar``: Radar data.
            - ``temperature``: Temperature data.

        Be aware, that frames can contain only a subset of data for the above mentioned sensor types, because the
        sensors are not physically aligned and return asynchronously data. If a sensor has no new data, ``None`` will be
        returned instead. Ensure in your code that you implement corresponding checks.
    """

    MAX_RETRIES = 3
    TIMEOUT_MS = 1000
    LOG_TEMPERATURE_S = 1
    config_file_suffix = ".json"

    def __init__(self, config_file: _PathLike, device_id: Optional[str] = None) -> None:
        self._device: DeviceFmcw
        self._tmp_config_dir = tempfile.TemporaryDirectory()  # pylint: disable=consider-using-with
        self._timestamp_last_temperature = 0.0
        super().__init__(config_file, device_id)

    @classmethod
    def _discover(cls, sensor_type: Optional[RadarSensor] = None) -> List[str]:
        log.debug("%s | Looking for devices...", cls.__name__)
        try:
            discovered_devices = DeviceFmcw.get_list(sensor_type)
        except OSError as excp:
            raise SensorError(
                "Old firmware detected - Please upgrade the firmware of all attached radar device to v2.6.0 or higher."
            ) from excp
        for uuid in discovered_devices:
            log.info("%s | Found device with UUID %s.", cls.__name__, uuid)
        return discovered_devices

    @classmethod
    def discover(cls) -> List[str]:
        """Discover connected Ifx Radar devices.

        Exemplary device identifier: `00000000-0000-4158-3130-333539393630`

        Returns:
            List of device identifiers for all connected devices.
        """
        return cls._discover()

    def _open_device(self) -> None:
        log.debug("%s: %s | Try to open radar device.", type(self).__name__, self._device_id)

        try:
            self._device = DeviceFmcw(uuid=self.device_id)
        except ErrorNoDevice as excp:
            raise SensorNotFoundError(f"Found no radar device with UUID {self.device_id}.") from excp
        self._device.start_acquisition()

    def _configure_device(self) -> None:
        if self.config_file.suffix == ".json":
            raw_config = self.parse_config_from_file(self._config_file)
            config_chirp = FmcwSequenceChirp(
                start_frequency_Hz=raw_config["start_frequency_Hz"],
                end_frequency_Hz=raw_config["end_frequency_Hz"],
                sample_rate_Hz=raw_config["sample_rate_Hz"],
                num_samples=raw_config["num_samples_per_chirp"],
                rx_mask=raw_config["rx_mask"],
                tx_mask=raw_config["tx_mask"],
                tx_power_level=raw_config["tx_power_level"],
                lp_cutoff_Hz=raw_config["aaf_cutoff_Hz"],
                hp_cutoff_Hz=raw_config["hp_cutoff_Hz"],
                if_gain_dB=raw_config["if_gain_dB"],
            )
            config_sequence = FmcwSimpleSequenceConfig(
                frame_repetition_time_s=raw_config["frame_repetition_time_s"],
                chirp_repetition_time_s=raw_config["chirp_repetition_time_s"],
                num_chirps=raw_config["num_chirps_per_frame"],
                tdm_mimo=raw_config["mimo_mode"],
                chirp=config_chirp,
            )
            config = DeviceFmcw.create_simple_sequence(config_sequence)
            try:
                self._device.set_acquisition_sequence(config)
            except (ErrorDevBase, TypeError) as excp:
                raise SensorConfigurationError("Failed to configure radar device.") from excp
        elif self.config_file.suffix == ".txt":
            try:
                self._device.load_register_file(self._config_file.as_posix())
            except (ErrorDevBase, TypeError) as excp:
                raise SensorConfigurationError("Failed to configure radar device registers.") from excp
        else:
            raise SensorConfigurationError(
                f"Supported file extensions: '.json', '.txt'. Got {self.config_file.suffix}."
            )

    def _start_device(self) -> None:
        pass

    def _close_device(self) -> None:
        self._device.stop_acquisition()
        del self._device
        log.debug("%s: %s | Deleted radar device handle.", type(self).__name__, self._device_id)
        self._tmp_config_dir.cleanup()
        log.debug("%s: %s | Cleaned temporary directory for configuration files.", type(self).__name__, self._device_id)

    def _get_frame_format(self) -> Dict[str, FrameFormat]:
        acquisition_sequence = self._device.get_acquisition_sequence()
        frame_sequence = acquisition_sequence.loop
        if len_sequence(frame_sequence) > 1:
            raise NotImplementedError("Multi shape support not implemented.")
        chirp_sequence = frame_sequence.sub_sequence[0].loop
        n_chirps = chirp_sequence.num_repetitions
        n_tx = len_sequence(chirp_sequence)
        chirp_config = chirp_sequence.sub_sequence.contents.chirp
        n_rx = len(antenna_mask_to_list(chirp_config.rx_mask))

        frame_format = {
            "radar": FrameFormat(
                dtype=np.dtype("uint16"),
                fps=1 / cast(float, frame_sequence.repetition_time_s),
                shape=(n_tx, n_rx, n_chirps, chirp_config.num_samples),
            ),
            "temperature": FrameFormat(dtype=np.dtype("float32"), fps=1 / RadarIfxAvian.LOG_TEMPERATURE_S, shape=(1,)),
        }
        return frame_format

    def _generate_meta_data(self) -> Dict[str, str]:
        device_information = self._device.get_sensor_information()
        meta_data = {
            "uuid": self.device_id,
            "sensor_type": self._device.get_sensor_type().value,
            "sdk_version": get_version_full(),
            "firmware_version": self._device.get_firmware_information()["extended_version"],
            "adc_resolution": 12,
            **device_information,
        }
        return meta_data

    def _get_data_from_device(self) -> Dict[str, Optional[Frame]]:
        for attempt in range(RadarIfxAvian.MAX_RETRIES):
            try:
                frame_content = self._device.get_next_frame(RadarIfxAvian.TIMEOUT_MS)
                timestamp = time.time()
            except ErrorTimeout:
                log.warning(
                    "%s: %s | Failed to get frame from radar device. (Retry %d/%d)",
                    type(self).__name__,
                    self._device_id,
                    attempt + 1,
                    RadarIfxAvian.MAX_RETRIES,
                )
                continue
            else:
                break
        else:
            raise TimeoutError("Failed to get frame from radar device.")

        # De-normalize data [-1..1 -> 0..4095] & unify in array [TX, RX, chirps, samples]
        data = np.stack([(raw_cube + 1) * 4095 / 2 for raw_cube in frame_content])
        data = data.astype(np.uint16)

        frame: Dict[str, Optional[Frame]] = {"radar": Frame(timestamp, data), "temperature": None}
        if (timestamp - self._timestamp_last_temperature) > RadarIfxAvian.LOG_TEMPERATURE_S:
            self._timestamp_last_temperature = timestamp
            try:
                temperature = self._device.get_temperature()
            except Exception:  # Uncertainty in RDK about raised exception |   # pylint: disable=broad-except
                pass
            else:
                frame["temperature"] = Frame(timestamp, np.array([temperature], dtype=np.float32))
        return frame

    @staticmethod
    def parse_config_from_file(config_file: _PathLike) -> Dict[str, Union[float, int, str]]:
        """Parse a configuration file according to RDK schema.

        Args:
            config_file: The configuration file.

        Raises:
            SensorConfigurationError: If an invalid `config_file` was passed.

        Returns:
            The parsed configuration.

        Note:
            Currently, only the `fmcw_single_shape` is supported.
            We do not read the UUIDs, because this is not required.
        """
        try:
            raw_config = read_json(config_file)
        except json.decoder.JSONDecodeError as excp:
            raise SensorConfigurationError("Invalid JSON file.") from excp

        try:
            device_config = raw_config["device_config"]
        except KeyError as excp:
            raise SensorConfigurationError("Configuration must contain `device_config`.") from excp

        try:
            ((schema, content),) = device_config.items()
            schema = SupportedSchemas(schema)
        except ValueError as excp:
            raise SensorConfigurationError(
                f"`device_config` must contain exactly one valid schema "
                f"({', '.join([f'`{schema.value}`' for schema in SupportedSchemas])})."
            ) from excp

        if schema == SupportedSchemas.FMCW_SINGLE_SHAPE:
            config = RadarIfxAvian.extract_fmcw_single_shape_device_config(content)

        return config

    @staticmethod
    @no_type_check
    def extract_fmcw_single_shape_device_config(
        raw_config: Dict[str, Union[float, int, List[int], str]]
    ) -> Dict[str, Union[float, int, str]]:
        """Extract device config from raw FMCW single shape config.

        Args:
            raw_config: FMCW single shape config.

        Raises:
            SensorConfigurationError: If keys are missing.

        Returns:
            Device configuration dictionary.
        """
        try:
            return {
                "rx_mask": antenna_list_to_mask(raw_config["rx_antennas"]),
                "tx_mask": antenna_list_to_mask(raw_config["tx_antennas"]),
                "tx_power_level": int(raw_config["tx_power_level"]),
                "if_gain_dB": int(raw_config["if_gain_dB"]),
                # Exploit `or` as a short-circuit operator to use the old frequency keys as a fallback option
                "start_frequency_Hz": raw_config.get("lower_frequency_Hz") or raw_config["start_frequency_Hz"],
                "end_frequency_Hz": raw_config.get("upper_frequency_Hz") or raw_config["end_frequency_Hz"],
                "num_chirps_per_frame": int(raw_config["num_chirps_per_frame"]),
                "num_samples_per_chirp": int(raw_config["num_samples_per_chirp"]),
                "chirp_repetition_time_s": raw_config["chirp_repetition_time_s"],
                "frame_repetition_time_s": raw_config["frame_repetition_time_s"],
                "hp_cutoff_Hz": int(raw_config.get("hp_cutoff_Hz", 80e3)),  # Optional
                "aaf_cutoff_Hz": int(raw_config.get("aaf_cutoff_Hz", 500e3)),  # Optional
                "sample_rate_Hz": raw_config.get("sample_rate_Hz", 1e6),  # Optional
                "mimo_mode": raw_config.get("mimo_mode", "off"),  # Optional
            }
        except KeyError as excp:
            raise SensorConfigurationError("Invalid raw_configuration in `fmcw_single_shape`.") from excp

    @staticmethod
    def write_config_to_file(configuration: Dict[str, Union[float, int, str]], config_file: _PathLike) -> None:
        """Write a radar configuration into a file.

        Args:
            configuration: Configuration to write.
            config_file: Output file.
        """
        _configuration: Dict[str, Union[float, int, List[int], str]] = {
            "rx_antennas": antenna_mask_to_list(int(configuration["rx_mask"])),
            "tx_antennas": antenna_mask_to_list(int(configuration["tx_mask"])),
            **configuration,
        }
        del _configuration["rx_mask"], _configuration["tx_mask"]

        with open(config_file, "w", encoding="utf-8") as file:
            json.dump({"device_config": {SupportedSchemas.FMCW_SINGLE_SHAPE.value: _configuration}}, fp=file, indent=4)


def antenna_mask_to_list(antenna_mask: int) -> List[int]:
    """Transform an antenna mask into an antenna list."""
    return [shift_ind + 1 for shift_ind in range(antenna_mask.bit_length()) if (antenna_mask >> shift_ind) & 1]


def antenna_list_to_mask(antenna_list: List[int]) -> int:
    """Transform an antenna list into an antenna mask."""
    return sum(1 << (antenna - 1) for antenna in antenna_list)


def len_sequence(sequence: FmcwSequenceLoop) -> int:
    """Length of a RDK configuration sequence."""
    elem = sequence.sub_sequence.contents
    n_elem = 1
    while elem.next_element:
        elem = elem.next_element.contents
        n_elem += 1
    return n_elem


class RadarIfxBGT60TR13C(RadarIfxAvian):
    """Infineon BGT60TR13C Radar."""

    @classmethod
    def discover(cls) -> List[str]:
        return super(RadarIfxBGT60TR13C, cls)._discover(RadarSensor.BGT60TR13C)


class RadarIfxBGT60UTR13D(RadarIfxAvian):
    """Infineon BGT60UTR13D Radar."""

    @classmethod
    def discover(cls) -> List[str]:
        return super(RadarIfxBGT60UTR13D, cls)._discover(RadarSensor.BGT60UTR13D)


class RadarIfxBGT60ATR24C(RadarIfxAvian):
    """Infineon BGT60ATR24C Radar."""

    @classmethod
    def discover(cls) -> List[str]:
        return super(RadarIfxBGT60ATR24C, cls)._discover(RadarSensor.BGT60ATR24C)
