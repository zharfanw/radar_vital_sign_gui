"""This module contains a generic recorder.

Internally, we use appropriate implementations for the various data streams.

See Also:
    * :ref:`file_format`
    * :mod:`~ifxdaq.fileio.json`: Implementations for ``.json`` files.
    * :mod:`~ifxdaq.fileio.npy`: Implementations for ``.npy`` files.
    * :mod:`~ifxdaq.fileio.mp4`: Implementations for ``.mp4`` files.

Examples:
    Open radar with default configuration & record the data:

    >>> from ifxdaq.sensor.radar_ifx import RadarIfxAvian
    >>> config_file = RadarIfxAvian.create_default_config_file()
    >>> with RadarIfxAvian(config_file) as device:
    ...     with DataRecorder("demo", device.frame_format, device.meta_data, device.config_file) as rec:
    ...         for i, (frame) in enumerate(device):
    ...             rec.write(frame)
    ...             if i > 99:
    ...                 break #  Record 100 frames
"""

from __future__ import annotations

import json
import logging
import shutil
from dataclasses import dataclass
from pathlib import Path
from typing import TYPE_CHECKING, Dict, Optional, Type

from ifxdaq.errors import RecorderError
from ifxdaq.fileio import CONFIG_FILE, FILE_FORMAT_VERSION, FILE_FORMAT_VERSION_FILE, META_DATA_FILE
from ifxdaq.fileio.json import ReaderJson, RecorderJson
from ifxdaq.fileio.mp4 import ReaderMp4, RecorderMp4
from ifxdaq.fileio.npy import ReaderNpy, RecorderNpy

if TYPE_CHECKING:
    from types import TracebackType

    from ifxdaq.custom_typing import _PathLike
    from ifxdaq.fileio.abc import ReaderABC, RecorderABC
    from ifxdaq.sensor.abc import Frame, FrameFormat

log = logging.getLogger(__name__)

__all__ = ["Map", "Mappings", "DataRecorder"]


@dataclass
class Map:
    """Map of an individual data stream."""

    suffix: str
    """Suffix of the data type."""
    recorder: Type[RecorderABC]
    """Used recorder class."""
    reader: Type[ReaderABC]
    """Used reader class"""


Mappings = {
    "depth": Map(".npy", RecorderNpy, ReaderNpy),
    "ir1": Map(".mp4", RecorderMp4, ReaderMp4),
    "ir2": Map(".mp4", RecorderMp4, ReaderMp4),
    "radar": Map(".npy", RecorderNpy, ReaderNpy),
    "rgb": Map(".mp4", RecorderMp4, ReaderMp4),
    "temperature": Map(".npy", RecorderNpy, ReaderNpy),
    "label": Map(".json", RecorderJson, ReaderJson),
    "generic-array": Map(".npy", RecorderNpy, ReaderNpy),
    "generic-scalar": Map(".json", RecorderJson, ReaderJson),
}


class DataRecorder:
    """Central recorder class.

    This is the central recorder of ``ifxdaq``. It should be used to record data with single
    sensors. The recorded data will be stored within a standalone directory. The directory
    contains:

        * recorded data
        * timestamps of the recorded data
        * meta data
        * configuration file

    Args:
        rec_dir: Path to store the data.
        frame_format: The frame format of all streams of the used sensor.
        meta_data: Meta data to store.
        config_file: Configuration file to store.
    """

    def __init__(
        self,
        rec_dir: _PathLike,
        frame_format: Dict[str, FrameFormat],
        meta_data: Dict[str, str],
        config_file: Optional[_PathLike] = None,
    ) -> None:
        self._rec_dir = Path(rec_dir)
        self._meta_data = meta_data

        self._rec_dir.mkdir(parents=True, exist_ok=False)

        self._write_meta_data()
        self._write_file_format_version()
        if config_file is not None:
            self._config_file = Path(config_file)
            self._write_config_file()

        self._init_recorder(frame_format)

        log.info("%s | Started recording.", self._rec_dir.as_posix())

    def _init_recorder(self, frame_format: Dict[str, FrameFormat]) -> None:
        self._recorders: Dict[str, RecorderABC] = {}
        for name, fmt in frame_format.items():
            try:
                mapping = Mappings[name]
            except KeyError as excp:
                raise RecorderError("No recorder for datastream available.") from excp

            file = self._rec_dir / f"{name}{mapping.suffix}"
            self._recorders[name] = mapping.recorder(file, fmt)

    def write(self, frames: Dict[str, Optional[Frame]]) -> None:
        """Write a set of data frames with the recorder.

        Args:
            frames: Set of data frames to record.

        Raises:
            RecorderError: If invalid data is fed into the recorder.
        """
        try:
            for name, frame in frames.items():
                if frame is None:
                    continue
                self._recorders[name].write(frame)
        except KeyError as excp:
            raise RecorderError("Unspecified data stream feed into the recorder") from excp

    def _write_config_file(self) -> None:
        """Write the config file into a recording."""
        shutil.copyfile(self._config_file, (self._rec_dir / CONFIG_FILE).with_suffix(self._config_file.suffix))

    def _write_meta_data(self) -> None:
        """Write the meta data into a recording."""
        with open(self._rec_dir / META_DATA_FILE, "w", encoding="utf-8") as file:
            json.dump(self._meta_data, file, indent=2)

    def _write_file_format_version(self) -> None:
        """Write a file containing the file format version."""
        with open(self._rec_dir / FILE_FORMAT_VERSION_FILE, "w", encoding="utf-8") as file:
            file.write(FILE_FORMAT_VERSION)
            file.write("\n")

    def __enter__(self: "DataRecorder") -> "DataRecorder":
        log.debug("Entered context manager.")
        return self

    def __exit__(
        self,
        exc_type: Optional[Type[BaseException]],
        exc_value: Optional[BaseException],
        traceback: Optional[TracebackType],
    ) -> None:
        self.close()
        log.debug("Exited context manager.")

    def close(self) -> None:
        """Close the recorder and stop the recording."""
        for rec in self._recorders.values():
            rec.close()
        log.info("%s | Ended recording.", self._rec_dir.as_posix())
