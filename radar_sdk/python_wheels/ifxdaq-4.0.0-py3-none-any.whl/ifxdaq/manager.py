"""This module contains the `SensorManager`, which is used to operate multiple sensors simultaneously."""

from __future__ import annotations

import datetime
import json
import logging
import multiprocessing as mp
import threading
from multiprocessing.dummy import Pool as ThreadPool
from pathlib import Path
from typing import TYPE_CHECKING, Dict, Iterable, List, Type, Union

from ifxdaq.errors import SensorError
from ifxdaq.manager_config import ManagerConfig, Sensor
from ifxdaq.multiproc.record import RecordingWorker
from ifxdaq.multiproc.visualize import VisualizationWorker
from ifxdaq.process import SensorProcess
from ifxdaq.utils.common import import_objects, log_from_queue, system_information

if TYPE_CHECKING:
    from ifxdaq.custom_typing import _PathLike
    from ifxdaq.multiproc.abc import WorkerABC
    from ifxdaq.sensor.abc import SensorABC

log = logging.getLogger(__name__)

__all__ = ["SensorManager"]


class SensorManager:
    """Class to manage multiple sensors on an abstract level.

    Currently supported sensors:
        * :class:`~ifxdaq.sensor.radar_ifx.RadarIfxAvian`
        * :class:`~ifxdaq.sensor.camera_irs.CamIntelRealSense`
        * :class:`~ifxdaq.sensor.camera_ocv.CamOpenCV`

    Warning:
        :class:`~ifxdaq.sensor.camera_ocv.CamOpenCV` has negative side effects
        on other cameras, e.g. :class:`~ifxdaq.sensor.camera_irs.CamIntelRealSense`
        and is disabled by default.

    Args:
        sensors: Sensors to use. List of module names, e.g. `ifxdaq.sensor.radar_ifx.RadarIfxAvian`.
        workers: Workers to use. List of classes, e.g. `RecordingWorker`.
        config_file: Configuration file for the manager.

    See Also:
        * :class:`~ifxdaq.manager_config.ManagerConfig`
        * :class:`~ifxdaq.manager_config.SensorConfig`
    """

    def __init__(
        self,
        sensors: Iterable[str] = (
            "ifxdaq.sensor.radar_ifx.RadarIfxBGT60TR13C",
            "ifxdaq.sensor.radar_ifx.RadarIfxBGT60UTR13D",
            "ifxdaq.sensor.radar_ifx.RadarIfxBGT60ATR24C",
            "ifxdaq.sensor.camera_irs.CamIntelRealSense",
        ),
        workers: Iterable[Type[WorkerABC]] = (RecordingWorker, VisualizationWorker),
        config_file: _PathLike = "config.yaml",
    ) -> None:
        self._supported_sensors: List[Type[SensorABC]] = import_objects(sensors)

        self._config_file = Path(config_file)
        if self._config_file.exists():
            self._config = ManagerConfig.from_config_file(self._config_file)
        else:
            self._config = ManagerConfig()

        self._sensors: Dict[str, Sensor] = {}
        self._workers = workers

        # Logging
        self._log_queue: "mp.Queue" = mp.Queue()
        self._log_thread = self._start_logging()

    @property
    def sensors(self) -> Dict[str, Sensor]:
        """The sensors managed by the sensor manager (Initially empty - run `discover` to find attached sensors)."""
        return self._sensors

    def _start_logging(self) -> threading.Thread:
        thread = threading.Thread(target=log_from_queue, args=(self._log_queue,))
        thread.start()
        return thread

    def _stop_logging(self) -> None:
        self._log_queue.put(None)
        self._log_thread.join()

    def discover(self) -> None:
        """Discover attached devices and update the internal sensor list and configuration."""

        def thread_discover(sensor: Type[SensorABC]) -> List[Sensor]:
            discovered_sensors = []
            try:
                discovered_sensors = [Sensor(sensor, device_id) for device_id in sensor.discover()]
            except SensorError as excp:
                log.error(excp)
                log.warning("%s | Discovering devices failed.", sensor.__name__)
            return discovered_sensors

        with ThreadPool(len(self._supported_sensors)) as pool:
            discovered_sensors = pool.map(thread_discover, self._supported_sensors)

        self._sensors = {}
        sensor_list: List[Sensor] = [dev for sensors in discovered_sensors for dev in sensors]  # Flatten list of lists
        for sensor in sensor_list:
            if sensor in self._config:
                name = self._config.get_name(sensor)
                sensor.config = self._config.get_config(name)
            else:
                name = self._config.add(sensor)
                sensor.config_file = sensor.cls.create_default_config_file(dst=self._config_file.parent, name=name)
                self._config.set_config(name, sensor.config)

            self._sensors[name] = sensor

        self._config.dump(self._config_file)

    def configure(self, name: str, config_file: _PathLike) -> None:
        """Configure the sensor with the provided configuration file.

        Args:
            name: Key indicating the sensor in the internal storage.
            config_file: File to configure the sensor.

        Raises:
            FileNotFoundError: If the provided `config_file` does not exist.
            IsADirectoryError: If the provided `config_file` is a directory instead of a file.
        """
        config_file = Path(config_file)
        if not config_file.exists():
            raise FileNotFoundError(f"Configuration file does note exist. {config_file}")
        if config_file.is_dir():
            raise IsADirectoryError(f"Configuration file is a directory. {config_file}")

        self.sensors[name].config_file = config_file
        # Update config
        self._config.set_config(name, self.sensors[name].config)
        self._config.dump(self._config_file)

    def start(self, name: str, timeout: float = 30) -> SensorProcess:
        """Start the sensor in a background process.

        Args:
            name: Key indicating the sensor in the internal storage.
            timeout: Maximum allowed time to open the sensor.

        Returns:
            The started process.
        """
        sensor = self.sensors[name]
        if sensor.process is not None:
            return sensor.process
        assert sensor.config_file is not None, "Configuration file must be set to open a sensor."

        sensor.process = SensorProcess(
            sensor=sensor.cls,
            config_file=sensor.config_file,
            device_id=sensor.device_id,
            workers=[worker() for worker in self._workers],
            log_queue=self._log_queue,
            timeout=timeout,
        )
        sensor.process.start()
        return sensor.process

    def close(self, name: str) -> None:
        """Close the sensor.

        Args:
            name: Key indicating the sensor in the internal storage.
        """
        sensor = self.sensors[name]
        if sensor.process is None:
            return

        sensor.process.close()
        sensor.process.join()
        sensor.process = None

    def close_all(self) -> None:
        """Close all open sensors."""
        closable_devices = [name for name, sensor in self.sensors.items() if sensor.process is not None]
        if closable_devices:
            with ThreadPool(len(closable_devices)) as pool:
                pool.map(self.close, closable_devices)

    def start_recording(self, recording_path: Union[Path, str] = Path.cwd()) -> Path:
        """Start a recording with all opened sensors.

        Args:
            recording_path: Recording will be written into this path. If not provided, the invoking path is used.

        Returns:
            Path of the recording.
        """
        now = datetime.datetime.now()
        recording_path = Path(recording_path)
        recording_path /= f"recording_{now:%Y_%m_%d_%H_%M_%S}"
        recording_path.mkdir(parents=True, exist_ok=False)

        # Dump meta data
        meta_data = system_information()
        meta_data["date_captured"] = now.isoformat()
        with open(recording_path / "meta.json", "w", encoding="utf-8") as file:
            json.dump(meta_data, file, indent=2)

        for name, sensor in self.sensors.items():
            if sensor.process is None:
                continue
            if sensor.process.recording is not None:
                sensor.process.recording.start_recording(recording_path / name)

        return recording_path

    def stop_recording(self) -> None:
        """Stop a recording."""
        for sensor in self.sensors.values():
            if sensor.process is None:
                continue
            if sensor.process.recording is not None:
                sensor.process.recording.stop()

    def start_visualization(self) -> None:
        """Start to forward visualizations."""
        for sensor in self.sensors.values():
            if sensor.process is None:
                continue
            if sensor.process.visualization is not None:
                sensor.process.visualization.start()

    def stop_visualization(self) -> None:
        """Stop to forward visualizations."""
        for sensor in self.sensors.values():
            if sensor.process is None:
                continue
            if sensor.process.visualization is not None:
                sensor.process.visualization.stop()

    def shutdown(self) -> None:
        """Shut the manager down."""
        self.stop_recording()
        self.stop_visualization()
        self.close_all()
        self._stop_logging()

    def __del__(self) -> None:
        self.shutdown()
