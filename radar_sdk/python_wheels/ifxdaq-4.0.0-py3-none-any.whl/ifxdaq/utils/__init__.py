"""This package contains generic helper functions."""
