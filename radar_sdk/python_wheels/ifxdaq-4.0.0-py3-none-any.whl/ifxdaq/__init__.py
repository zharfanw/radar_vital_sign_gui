"""**ifxdaq** is a framework to use different sensors from Python.

In a nutshell **ifxdaq** provides:

* An easy & pythonic way to handle sensors - no need to worry about low-level functionality.
* The same API for different sensors, e.g. cameras & radar.
* Wrappers to use multiple sensors in parallel.
* Tools to record data from sensors and store it in files.
* Functionality to read recorded data (-> virtual sensors for offline development & testing).
"""
import os
import warnings
from importlib.metadata import version
from pathlib import Path

__version__ = version("ifxdaq")

ENV_IFXDAQ_CACHE = "IFXDAQ_CACHE"

try:
    # `ultralytics`, our labeling backend, has `opencv-python` as a requirement to plot the results of inference and to
    # show the results in small GUI windows. We use only the plotting functionality.
    # On the other hand, `opencv-python` has some compatibility issues with PySide6, which can be avoided with
    # `opencv-python-headless` (OpenCV without GUI functionality).
    # https://github.com/opencv/opencv-python/issues/46
    # https://forum.qt.io/topic/119109
    #
    # We check here if `opencv-python` is installed and replace it with `opencv-python-headless`. The check is done
    # every time, but the actual replacement is a one time execution.
    version("opencv-python")

    warnings.warn("Replacing `opencv-python` with `opencv-python-headless`.")
    import subprocess
    import sys

    subprocess.check_call([sys.executable, "-m", "pip", "uninstall", "-y", "opencv-python"])
    subprocess.check_call(
        [sys.executable, "-m", "pip", "install", "--no-deps", "--force-reinstall", "opencv-python-headless"]
    )
except ModuleNotFoundError:
    pass


def get_cache_dir() -> Path:
    """Get ifxdaq's cache directory."""
    return Path(os.getenv(ENV_IFXDAQ_CACHE, (Path.home() / ".cache" / "ifxdaq").as_posix()))
